Example
=======

The example script is provided in the repository (https://git.cbm.gsi.de/DAQ-WUT/smx_tester), file :code:`sw/interactive_work.py`.
