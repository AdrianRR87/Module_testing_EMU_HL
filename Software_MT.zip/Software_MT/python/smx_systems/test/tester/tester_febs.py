import time
import sys
import os
import logging
import pprint
import uhal

sys.path.append('../autogen/agwb/python/')

import agwb

#import test_setup as setup
from smx_tester import *
import msts_defs as smc
#from opm import Opm


def rawfifo_to_smxframes(rfifo_dat):
    smxframes = {}
    for u in rfifo_dat.keys():
        smxframes[u] = []
        for d in rfifo_dat[u]:
            smxframes[u].append(format.smx.determinator(d.smxframe))
            # systime is not a part of smxframe, but is is convenient to add it to python class
            smxframes[u][-1].systime = d.systime

    return smxframes
            


emu_list = ["EMU_131"]

link_scan = True
device_scan = True
link_sync = True


# -----------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s,%(msecs)03d:%(module)s:%(levelname)s:%(message)s",
    datefmt="%H:%M:%S",
)

log = logging.getLogger()
fh = logging.FileHandler(sys.argv[0].replace('py', 'log'), 'w')
fh.setLevel(logging.DEBUG)
fmt = logging.Formatter('[%(levelname)s] %(message)s')
fh.setFormatter(fmt)
log.addHandler(fh)

uhal.setLogLevelTo(uhal.LogLevel.WARNING)

# ------------------------------------------------------------------------------------

manager = uhal.ConnectionManager("file://devices.xml")
setup_elements = []
emu_elements = []

for emu in emu_list:
    ipbus_interface = IPbusInterface(manager, emu)
    agwb_top = agwb.top(ipbus_interface, 0)
    smx_tester = SmxTester(agwb_top, CLK_80)
    setup_elements_tmp = smx_tester.scan_setup()
    log.info("setup_elements_tmp: %d", len(setup_elements_tmp))
    setup_elements.extend(setup_elements_tmp)
    emu_elements.extend( [emu for i in range(len(setup_elements_tmp))])

    
# Temporary workaround becase there are no independent elink clocks.
# setup_elements = [setup_elements[0]]
# smx_tester.elinks.disable_downlink_clock(4)

if link_scan:
    for se in setup_elements:
        se.characterize_clock_phase()
        se.initialize_clock_phase()
        pass
        
    for se in setup_elements:
        se.characterize_data_phases()
        se.initialize_data_phases()
        pass
        
if device_scan:        
    for se in setup_elements:
        se.scan_smx_asics_map()

if link_sync:        
    for se in setup_elements:
        se.synchronize_elink()
        pass
        
    for se in setup_elements:
        se.write_smx_elink_masks()
        pass
        
smxes = []
for se, emu in zip(setup_elements, emu_elements):
    smxes_tmp = smxes_from_setup_element(se)
    log.info("smxes_tmp: %d", len(smxes_tmp))
    for smx in smxes_tmp:
        smx.rob = int(emu[4:])
    smxes.extend(smxes_tmp)
 
print(emu_elements) 
 
log.info("Number of setup elements: %d", len(setup_elements))
log.info("Number of smx: %d", len(smxes))
log.info("")

# -----------------------------------------------------------
# --- User tests start here 
# -----------------------------------------------------------

# define list of ASICs used for tests
#  this is a sublist of the detected Asics 'smxes' 
#smx_l = smxes[0:3]   # example: first three(!) Asics 
smx_l = smxes # [0:1]      # all Asics

#opm = Opm(smx_l)
 
# configure Asics with default configuration and readback config registers 
#  - configuration from 'default' dictionary in file smx_tester/mcbm_msts_active_params.py
for smx in smx_l:
    log.info("Asic (emu %d   downlink %d   hw_addr %d): ", smx.rob, smx.downlink, smx.address)
    smx.func_to_reg(smc.R_ACT)
    smx.write_reg_all()
    smx.read_reg_all(compFlag = False)

# all below are just examples andare optional 

# --- Do some tests --------

log.info("Reading SMX chip address")
for smx in smx_l:
    addr = smx.read(192, 22)
    log.info("Asic address (emu %d   downlink %d   hw_addr %d): \t %d", smx.rob, smx.downlink, smx.address, addr)

for smx in smx_l:
	smx.reset_asic()

for smx in smx_l:
    smx.set_channel_mask_enable_all()

#  set selected parameters  
#  - example: set the CSA currents
#      - list of available Asic config setting names: see the above file
for smx in smx_l:
    smx.conf_func("csa_front",31)
    smx.conf_func("csa_back", 31)
    log.info(" CSA settings: front %d   back %d", smx.read(130,0)&0xff, smx.read(130,13)&0xff)

for smx in smx_l:
    smx.conf_func("vref_p", 57)
    smx.conf_func("vref_n", 25)
    smx.conf_func("vref_t", 40)
    log.info(" Vref settings: vref_p %d   vref_n %d       vref_t %d", smx.read(130,0)&0xff, smx.read(130,0)&0xff, smx.read(130,13)&0xff)

for smx in smx_l:
    #smx.set_trim_default(128,15)
    pass

for smx in smx_l:    
    log.info(f"vref_n(130,8): {smx.read(130,8)&0xff}   vref_p(130,9): {smx.read(130,9)&0xff}")

for smx in smx_l:
    v_diag, dac_diag = smx.read_diag("Temp")
    log.info("Asic %d: Temp %f mV (ADC %d)", smx.address, v_diag, dac_diag)
    log.info("Asic %d: Temp calib. %f ", smx.address, smx.read_temp())
    v_diag, dac_diag = smx.read_diag("Vddm")
    log.info("Asic %d: Vddm %f mV (ADC %d)", smx.address, v_diag, dac_diag)

log.info("")
#  Get some specific smx by (downlink, hw_address) or (downlink, aseq)


#   "aseq" is "asic_number"
#smx = opm.smx_dl_aseq(1,0) #original
try:
    #smx = opm.smx_dl_hw(1,4) #my
    #smx = smx_l[0]
    addr = smx.read(192, 22)
    log.info("Asic address (emu %d   downlink %d   aseq %d): \t %d", smx.rob, smx.downlink, smx.aseq, addr)
except:
    pass


smx_l_short = smx_l[0:2]
for smx in smx_l_short:
    smx.daq_enable()
    smx_tester.reset_hit_fifos(smx.uplinks)
    smx.gen_test_pulses(333, 80)
    log.info(f"Asic {smx.hw_addr} - Number of acquired data: {str(smx_tester.fifos_data_count(smx.uplinks))}")
    hit_fifo_data = smx_tester.read_fifos_data(256, smx.uplinks, withsystime=False)
    smx.read_adc_counter()

    smxframes = rawfifo_to_smxframes(hit_fifo_data)
    for u in smxframes.keys():
        for f in smxframes[u]:
            print(f)
	


