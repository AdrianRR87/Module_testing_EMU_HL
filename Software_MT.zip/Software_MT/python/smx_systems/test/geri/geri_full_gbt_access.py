import sys
import time
import geri

import smx

import logging as log

# GBT (SFP) port that should be used
ports = [0,2]
  
def hhex(val):
  l = val&0xF
  u = (val>>4)&0xF
  print(f"0x{val:02x} : {u:04b}_{l:04b}")


log.basicConfig(level=log.DEBUG, format='%(filename)s:%(lineno)d - %(message)s')

g=geri.Geri()                       # g: GERI     multiples?
g.init()

ports_active = []
for port in ports:
    g.gbtfpga[port].init(attempts=20)
    time.sleep(5)
    print(g.gbtfpga[port].gbtfpga_get_link_status())

    for i in range(10):
        # sometimes the first operation fails...
        # TODO: identify and fix the problem
        try:
            ver=g.gbtfpga[port].emu_regs.VER.read()
            print(f"Succeeded in : {i}")
            ports_active.append(port)
            break
        except Exception as e:
            pass
    else:
        print("Didn't work!")

setup_elements = []
port_elements = []
        
for port in ports_active:
    ver=g.gbtfpga[port].emu_regs.VER.read()
    id=g.gbtfpga[port].emu_regs.ID.read()
    print(f"Read GBTxEMU firmware ID: 0x{id:08x} and VER: 0x{ver:08x}")

    setup_elements_tmp = g.scan_setup(port)
    log.info("setup_elements_tmp: %d", len(setup_elements_tmp))
    setup_elements.extend(setup_elements_tmp)
    port_elements.extend( [port for i in range(len(setup_elements_tmp))])

for se in setup_elements:
    se.characterize_clock_phase()
    se.initialize_clock_phase()
    se.characterize_data_phases()
    se.initialize_data_phases()
    se.scan_smx_asics_map()
    se.synchronize_elink()
    se.hctsp_uplink.set_uplinks_mask()
    se.write_smx_elink_masks()

smxes = []
for se, port in zip(setup_elements, port_elements):
    smxes_tmp = smxes_from_setup_element(se)
    log.info("smxes_tmp: %d", len(smxes_tmp))
    for smx in smxes_tmp:
        smx.rob = int(port)
    smxes.extend(smxes_tmp)

smx_l = smxes # [0:2]
    
log.info("Number of ports: %d", len(port_elements))
log.info(f"Ports: {port_elements}")
log.info("Number of setup elements: %d", len(setup_elements))
log.info("Number of smx: %d", len(smxes))
log.info("Number of selected smx: %d", len(smx_l))
log.info("")
    
for smx in smx_l:
    smx.refclk_frq=80e6
    smx.reset_asic()
    smx.set_config_flags(0xc)
    smx.daq_disable()
    #sx0.write(192,14,0)
    #sx0.write(192,15,0xff)

# Test: data generation and readout
rate = 2
duration = 20 # sec
for smx in smx_l:
    smx.set_test_mode_fix(rate,1,0,duration)
for smx in smx_l:
    smx.daq_enable()
    
#Configure generation of packet every second
g.regs.datapath.triv_proc.pkt_duration.write(40000000)
#Start DMA
g.regs.datapath.triv_proc.ctrl.reset.writef(1)
time.sleep(0.1)
g.regs.datapath.triv_proc.ctrl.reset.writef(0)
time.sleep(0.1)
g.regs.datapath.triv_proc.ctrl.run.writef(1)
