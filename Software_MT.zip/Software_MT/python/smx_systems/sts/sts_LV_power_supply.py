import sys
import time
import os
import numpy as np
import logging as log

class sts_LV_PowerSupply():
	
	# LV mapping
	# LV channels vs FEB
	# u800 ................ 1.8 V LDOs N-side
	# u801 ................ 1.2 V LDOs N-side
	# u802 ................ 1.8 V LDOs P-side
	# u803 ................ 1.2 V LDOs P-side

	def __init__(self, ip_LV_address: str):
		
		self.ip_LV_address = ip_LV_address
		
	def turnOn_LV_sideX(self, self.sideX: str):
		self.sideX = sideX 
		if (sideX = 'n-side' or 'N-side' or 'n' or 'N' or '0'):
			print ("Turning ON Low Voltage for N-side (electrons polarity):" )
			#Turning ON Voltage for N-side
			os.system("ssh cbm@cbmflib01 ./mpod_lab2021/lab21_mpod02_u800 on")
			os.system("ssh cbm@cbmflib01 ./mpod_lab2021/lab21_mpod02_u801 on")
		elif(sideX = 'p-side' or 'P-side' or 'p' or 'P' or '1'):
			print ("Turning ON Low Voltage for P-side (holes polarity):" )
			#Turning ON Voltage for P-side
			os.system("ssh cbm@cbmflib01 ./mpod_lab2021/lab21_mpod02_u802 on")
			os.system("ssh cbm@cbmflib01 ./mpod_lab2021/lab21_mpod02_u803 on")
		else:
			log.error("Please, indicate a polarity for reading the corresponding LV potentials, in the following way:")
			log.error("N or 0 for n-side, 0 for electrons polarity")
			log.error("P or 1 for p-side, 1 for holes polarity")
			sys.exit()  
		
	def turnOff_LV_sideX(self, self.sideX: str):
		self.sideX = sideX 
		if (sideX = 'n-side' or 'N-side' or 'n' or 'N' or '0'):	
			print ("#Turning OFF Low Voltage for N-side (electrons polarity):" )
			#Turning OFF Voltage for N-side
			os.system("ssh cbm@cbmflib01 ./mpod_lab2021/lab21_mpod02_u800 off")
			os.system("ssh cbm@cbmflib01 ./mpod_lab2021/lab21_mpod02_u801 off")
		elif(sideX = 'p-side' or 'P-side' or 'p' or 'P' or '1'):
			print ("Turning OFF Low Voltage for P-side (holes polarity):" )
			#Turning OFF Voltage for P-side
			os.system("ssh cbm@cbmflib01 ./mpod_lab2021/lab21_mpod02_u802 off")
			os.system("ssh cbm@cbmflib01 ./mpod_lab2021/lab21_mpod02_u803 off")
		else:
			log.error("Please, indicate a polarity for reading the corresponding LV potentials, in the following way:")
			log.error("N or 0 for n-side, 0 for electrons polarity")
			log.error("P or 1 for p-side, 1 for holes polarity")
			sys.exit()
			
	def readPar_LV_sideX(self, self.sideX: str):
		if (sideX = 'n-side' or 'N-side' or 'n' or 'N' or '0'):
			print ("Reading Low Voltage for N-side (electrons polarity):" )
			#Reading LV parameters for N-side
			os.system("ssh cbm@cbmflib01 ./mpod_lab2021/lab21_mpod02_u800 voltage | grep -Eo '[0-9]+([.][0-9]+)' > lv_iv.txt")
			os.system("ssh cbm@cbmflib01 ./mpod_lab2021/lab21_mpod02_u801 voltage | grep -Eo '[0-9]+([.][0-9]+)' >> lv_iv.txt")
		elif(sideX = 'p-side' or 'P-side' or 'p' or 'P' or '1'):
			print ("Reading Low Voltage for P-side (holes polarity):" )
			#Reading LV parameters for P-side
			os.system("ssh cbm@cbmflib01 ./mpod_lab2021/lab21_mpod02_u802 voltage | grep -Eo '[0-9]+([.][0-9]+)' > lv_iv.txt")
			os.system("ssh cbm@cbmflib01 ./mpod_lab2021/lab21_mpod02_u803 voltage | grep -Eo '[0-9]+([.][0-9]+)' >> lv_iv.txt")
		else:
			log.error("Please, indicate a polarity for reading the corresponding LV potentials, in the following way:")
			log.error("N or 0 for n-side, 0 for electrons polarity")
			log.error("P or 1 for p-side, 1 for holes polarity")
			sys.exit()
	
		#Open filename to read values
		filename_tmp_lv =  open("lv_iv.txt",'r')
		#perform file operations
		lv_18 = filename_tmp_lv.readline().strip()
		i_18   = filename_tmp_lv.readline().strip()
		lv_12 = filename_tmp_lv.readline().strip()
		i_12   = filename_tmp_lv.readline().strip()
		# closing temporary LV file
		filename_tmp_lv.close()

		print "LV values: "
		if (sideX = 'n-side' or 'N-side' or 'n' or 'N' or '0'):
		  print "LV_12_N [V]: " + str(lv_12) + " I_12_N [A]: " +str(i_12)
		  print "LV_18_N [V]: " + str(lv_18) + " I_18_N [A]: " +str(i_18)
		else():
		  print "LV_12_P [V]: " + str(lv_12) + " I_12_P [A]: " +str(i_12)
		  print "LV_18_P [V]: " + str(lv_18) + " I_18_P [A]: " +str(i_18)
