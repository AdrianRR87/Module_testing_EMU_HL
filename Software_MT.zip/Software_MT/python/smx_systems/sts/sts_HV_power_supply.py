import sys
import time
import os
import numpy as np
import logging as log

class sts_HV_PowerSupply():
	
	# HV mapping
	# HV channels vs FEB
	# u016 ................ N-side
	# u017 ................ P-side

	def __init__(self, ip_LV_address: str):
		
		self.ip_LV_address = ip_LV_address
		
	def set_HV_ON(self, self.hv_value: int):
		# Turning On HV simultaneously and symmetrically for both sides 
		print("Setting sensor HV at {}", hv_value)
		hv_side = hv_value/2
		os.system("ssh cbm@cbmflib01 ./mpod_lab2021/lab21_mpod02_u016 on {}", hv_side)
		os.system("ssh cbm@cbmflib01 ./mpod_lab2021/lab21_mpod02_u017 on {}", hv_side)
	
	def set_HV_ON_Xside(self, self.sideX: str, slef.hv_value: int):
		# Turning On HV simultaneously and asymmetrically 
		
		self.hv_value = hv_value
		self.sideX = sideX
		
		if (sideX = 'n-side' or 'N-side' or 'n' or 'N' or '0'):	
			print ("Setting sensor HV N-side at {}", hv_value)
			print ("P-side is kept at 0 V")
			os.system("ssh cbm@cbmflib01 ./mpod_lab2021/lab21_mpod02_u016 on {}", hv_value)
			os.system("ssh cbm@cbmflib01 ./mpod_lab2021/lab21_mpod02_u017 on {}", 0)
		elif(sideX = 'p-side' or 'P-side' or 'p' or 'P' or '1'):
			print ("Setting sensor HV P-side at {}", hv_value)
			print ("N-side is kept at 0 V")
			os.system("ssh cbm@cbmflib01 ./mpod_lab2021/lab21_mpod02_u016 on {}", 0)
			os.system("ssh cbm@cbmflib01 ./mpod_lab2021/lab21_mpod02_u017 on {}", hv_value)
		else:
			log.error("Please, indicate a polarity for reading the corresponding LV potentials, in the following way:")
			log.error("N or 0 for n-side, 0 for electrons polarity")
			log.error("P or 1 for p-side, 1 for holes polarity")
			sys.exit()
		
