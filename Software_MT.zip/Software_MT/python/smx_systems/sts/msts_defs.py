R_INI  = 0
R_ACT  = 1
R_RBK  = 2
NR_SET = 3

SMX_CONF = 0
SMX_PICK = 1

UTC = 1
MASTER = 2

# FEB type to feb type number
fno = {
    'a': 0,
    'b': 1
}

# FEB charge to feb charge number
cno = {
    'p': 1,
    'n': 0
}

# mapping of ASIC number to ASIC HW address
ahw = {
    'a': [ 7, 6, 5, 4, 3, 2, 1, 0 ],   # LV to readout
    'b': [ 1, 0, 3, 2, 5, 4, 7, 6 ]     # readout to LV
}


# mSTS 2021 specific: mapping from crob[0...4] to slr, crob_idx, crob index in slr
cslr = {
    0: {'slr': 0, 'idx': 2, 'iface': "B2"},
    1: {'slr': 0, 'idx': 1, 'iface': "B1"},
    2: {'slr': 1, 'idx': 2, 'iface': "D2"},
    3: {'slr': 1, 'idx': 0, 'iface': "D1"},
    4: {'slr': 1, 'idx': 1, 'iface': "D0"}
}

clktr = {0: (0, 0), 8: (0, 4), 2: (0, 1), 4: (0, 3), 6: (0, 2) }

'''
cslr = {
    0: {'slr': 0, 'idx': 5},
    1: {'slr': 0, 'idx': 4},
    2: {'slr': 1, 'idx': 5},
    3: {'slr': 1, 'idx': 4},
    4: {'slr': 1, 'idx': 3}
}
'''

dl2feb = {
    0: 0,
    1: 2,
    2: 3,
    3: 4,
    4: 1,
}

feb_uplinks = {
	0: [35,34,33,38,40,37,39,41],
	1: [19,22,32,31,30,29,36,28],
	2: [25,27,15,14,24,23,21,20],
	3: [13, 7, 6, 5,18,26,17,16],
	4: [12, 8, 4, 3, 9, 2, 1, 0]
}

