import sys

sys.path.append("smx_systems/smx/")
from smx_asic import SmxAsic
from smx_conf import SmxConf

class StsAsic(SmxAsic):
    def __init__(self, a_id: int, smx_conf: SmxConf, def_dict: dict, asic_dict: dict):
        super().__init__(a_id, smx_conf, def_dict)
        #super().__init__(_smxFeb, asic_dict)
        # super(SmxAsic, self).__init__(_smxFeb, asic_dict)
        # super(Smx, self).__init__()

        # geom
        self.module = -1
        self.ladder = -1
        self.quadrant = -1 
        self.station = -1 

        #self.smc = smx_conf
        #for f, d in def_dict.items():
        #    # remove d_ from "default" key for attribute name
        #    fa = f[2:]
        #    setattr(self, fa, d)
        #    # print( getattr(self,fa) )


    def set_stsm(self, stsm):
        """ Sets the mstsOpMan 
        for references and information retrieval from asic level
        args: mstsOpMan instance
        returns: na
        """
        self.stsm = stsm



    def setup(self, asic: int, feb: int, module: int, ladder: int, quadrant: int, station: int):
        """ Sets ASIC geometry coordinates 
        i.e. asic sequence and FEB and the module and module location (module, ladder, quadrant, station 
             module(0,..,4), ladder(0,..,7), quadrant(0,..,3), station(0,..,7) 
        args: 6 asic coordinates: (aseq, feb) and (module, ladder, quadrant, station)
        returns: na
        """
        log.info("SEEETTTUUUUPPPPP")
        # ToDo: add some asserts to check parameter ranges
        self.aseq = asic
        self.feb = feb
        self.module = module
        self.ladder = ladder
        self.quadrant = quadrant
        self.station = station
        
        
    def set_mask_from_channels(self, ch_list: list):
        ''' update channel mask from list of channel numbers 
              to mask out noisy channels
        args:  ch_list
                   list of channel numbers for whole module (i.e. ch 0,...,2047)
                   means channel mask update depends also on self.aseq
        returns: na
        result:
            update of self.mask
            update of mask registers[R_ACT]
            write mask registers to HW
        '''
        for ch in ch_list:
            ch_pre = ch
            if ch < 1024:
                ch = ch + 1024
            else:
                ch = 2047 - ch
            a = ch // 128
            aseq16 = self.aseq
            if self.chrg == 'n':
                aseq16 += 8
            if a != aseq16:
                continue
            log.debug(f"mask map {ch_pre} to {ch}  ")
            a_ch = ch % 128
            a_reg = (a_ch // 14)
            r_col = a_reg + 4
            r_bit = a_ch % 14

            self.mask = self.mask | 1 << a_ch
            r_val_rb = self.get_reg(smc.R_ACT, 192, r_col)
            r_val_new = r_val_rb | 1 << r_bit
            self.set_reg(smc.R_ACT, 192, r_col, r_val_new)
            self.write(192, r_col, r_val_new)
