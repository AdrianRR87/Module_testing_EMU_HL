
#  [seq name]
#        [sts chrg febtype  elink asic_rev]  [sts chrg febtype  elink asic_rev]         
# TODO:
#   rename setup to "modules" or similar
#   make it a dictionary, or generate dict from list?
setup = {
    1  : [ [1, 'p', 'a', 0x00001, 2], [1, 'n', 'b', 0x00001, 2] ],   # 01Tr-3
    2  : [ [1, 'p', 'a', 0x00001, 2], [1, 'n', 'b', 0x00001, 2] ],   # 02Tr-3
    3  : [ [1, 'p', 'b', 0x00001, 1], [1, 'n', 'a', 0x00001, 1] ],   # 01Tl-4
    4  : [ [1, 'p', 'b', 0x00001, 1], [1, 'n', 'a', 0x00001, 1] ],   # 02Tl-3 
    5  : [ [1, 'p', 'a', 0x00001, 2], [1, 'n', 'b', 0x00001, 2] ],   # 01Tr-4         cross check 'p'ol'a'rity!! 
    6  : [ [1, 'p', 'a', 0x00001, 2], [1, 'n', 'b', 0x00001, 2] ],   # 03Tr-2       cross check 'p'ol'a'rity!! 
    7  : [ [1, 'p', 'b', 0x00001, 1], [1, 'n', 'a', 0x00001, 1] ],   # 01Tl-6 
    8  : [ [1, 'p', 'b', 0x00001, 1], [1, 'n', 'a', 0x00001, 1] ],   # 02Tl-5 
    9  : [ [1, 'p', 'b', 0x00001, 1], [1, 'n', 'a', 0x00001, 1] ],   # 03Tl-3 
    10 : [ [1, 'p', 'b', 0x00001, 1], [1, 'n', 'a', 0x00001, 1] ],   # 01Tl-1/2/3 COSY     cross check 'p'ol'a'rity!! 
    11 : [ [1, 'p', 'b', 0x00001, 1], [1, 'n', 'a', 0x00001, 1] ],   # 03Tl-1       cross check polarity!!
    12 : [ [1, 'p', 'a', 0x00001, 1], [1, 'n', 'a', 0x00001, 1] ],   # dummy module for u1 pulser FEB
    13 : [ [1, 'p', 'a', 0x00001, 2], [1, 'n', 'a', 0x00001, 2] ]    # dummy module for u2 pulser FEB
}
    
m_name2seq = {
    "01Tr-3" :  1, 
    "02Tr-3" :  2, 
    "01Tl-4" :  3,   
    "02Tl-3" :  4,  
    "01Tr-4" :  5,  
    "03Tr-2" :  6,  
    "01Tl-6" :  7,
    "02Tl-5" :  8,
    "03Tl-3" :  9,
    "01Tl-3" : 10,   # 01Tl-1/2/3 COSY 
    "03Tl-1" : 11,
    "pulser_0" : 12,
    "pulser_1" : 13
}

# ToDo: module calibration parameters
# three parameters for each FEB8:
#   [calib_threshold in e, ADC_LSB in e, calib_vreft]
#  additional info needed:
#       vref_t_LSB in e ( for the proper vref_t range)
#  note: calib_vreft should be redundant with calib_threshold, since
#         for a given calib_threshold, it should be possible to
#         determine the corresponding vref_t ( for ANY vref_t range)
#         and then to determine the necessar vref_t value to decrease
#         the threshold as needed
#         Would be a dict like
#          vreft_range = {
#            0: {offset: 3000, step: 131.5},            # currently all arbitrary values
#            1: {offset: 3050, step: 549.7},           #  just for illustration
#            2: {offset: 2970, step: 298.0},
#            3: {offset: -20100, step: 195.1},
#         }
#         with [thr_at_vret_zero, vref_t_LSB] for each range
m_calib = {
    1 : [[11251,2567,58],[10311,2624,58]],
    2 : [[11251,2567,58],[10311,2624,58]],
    3 : [[11251,2567,58],[10311,2624,58]],
    4 : [[11251,2567,58],[10311,2624,58]],
    5 : [[11251,2567,58],[10311,2624,58]],
    6 : [[11251,2567,58],[10311,2624,58]],
    7 : [[11251,2567,58],[10311,2624,58]],
    8 : [[11251,2567,58],[10311,2624,58]],
    9 : [[11251,2567,58],[10311,2624,58]],
   10 : [[11251,2567,58],[10311,2624,58]],
   11 : [[11251,2567,58],[10311,2624,58]],
   12 : [[11251,2567,58],[10311,2624,58]],
   13 : [[11251,2567,58],[10311,2624,58]],
}


m_seq2name = dict(map(reversed, m_name2seq.items())) 

setup_modules = m_name2seq



# seq: sta quad lad mod  
geom = {
    1  : [ 0, 0, 0, 0],
    2  : [ 0, 0, 0, 1],
    3  : [ 0, 0, 1, 0],
    4  : [ 0, 0, 1, 1],
    5  : [ 1, 0, 1, 0],
    6  : [ 1, 0, 1, 1],
    7  : [ 1, 0, 0, 0],
    8  : [ 1, 0, 0, 1],
    9  : [ 1, 0, 0, 2],
    10 : [ 1, 0, 2, 0],
    11 : [ 1, 0, 2, 1],
    12 : [ 0, 0, 1, 2],
    13 : [ 1, 0, 1, 2]
}


# seq type ID
# TODO: replace by real ASIC ID
asics = {
    1 : [ [ 0x0010, 0x0011, 0x0012, 0x0013, 0x0014, 0x0015, 0x0016, 0x0017],  [ 0x0018, 0x0019, 0x001a, 0x001b, 0x001c, 0x001d, 0x001e, 0x001f] ],
    2 : [ [ 0x0020, 0x0021, 0x0022, 0x0023, 0x0024, 0x0025, 0x0026, 0x0027],  [ 0x0028, 0x0029, 0x002a, 0x002b, 0x002c, 0x002d, 0x002e, 0x002f] ],
    3 : [ [ 0x0030, 0x0031, 0x0032, 0x0033, 0x0034, 0x0035, 0x0036, 0x0037],  [ 0x0038, 0x0039, 0x003a, 0x003b, 0x003c, 0x003d, 0x003e, 0x003f] ],
    4 : [ [ 0x0040, 0x0041, 0x0042, 0x0043, 0x0044, 0x0045, 0x0046, 0x0047],  [ 0x0048, 0x0049, 0x004a, 0x004b, 0x004c, 0x004d, 0x004e, 0x004f] ],
    5 : [ [ 0x0050, 0x0051, 0x0052, 0x0053, 0x0054, 0x0055, 0x0056, 0x0057],  [ 0x0058, 0x0059, 0x005a, 0x005b, 0x005c, 0x005d, 0x005e, 0x005f] ], 
    6 : [ [ 0x0060, 0x0061, 0x0062, 0x0063, 0x0064, 0x0065, 0x0066, 0x0067],  [ 0x0068, 0x0069, 0x006a, 0x006b, 0x006c, 0x006d, 0x006e, 0x006f] ], 
    7 : [ [ 0x0070, 0x0071, 0x0072, 0x0073, 0x0074, 0x0075, 0x0076, 0x0077],  [ 0x0078, 0x0079, 0x007a, 0x007b, 0x007c, 0x007d, 0x007e, 0x007f] ],
    8 : [ [ 0x0080, 0x0081, 0x0082, 0x0083, 0x0084, 0x0085, 0x0086, 0x0087],  [ 0x0088, 0x0089, 0x008a, 0x008b, 0x008c, 0x008d, 0x008e, 0x008f] ],
    9 : [ [ 0x0090, 0x0091, 0x0092, 0x0093, 0x0094, 0x0095, 0x0096, 0x0097],  [ 0x0098, 0x0099, 0x009a, 0x009b, 0x009c, 0x009d, 0x009e, 0x009f] ],
   10 : [ [ 0x00a0, 0x00a1, 0x00a2, 0x00a3, 0x00a4, 0x00a5, 0x00a6, 0x00a7],  [ 0x00a8, 0x00a9, 0x00aa, 0x00ab, 0x00ac, 0x00ad, 0x00ae, 0x00af] ],
    11 : [ [ 0x00b0, 0x00b1, 0x00b2, 0x00b3, 0x00b4, 0x00b5, 0x00b6, 0x00b7],  [ 0x00b8, 0x00b9, 0x00ba, 0x00bb, 0x00bc, 0x00bd, 0x00be, 0x00bf] ],
    12 : [ [ 0x00c0, 0x00c1, 0x00c2, 0x00c3, 0x00c4, 0x00c5, 0x00c6, 0x00c7],  [ 0x00c8, 0x00c9, 0x00ca, 0x00cb, 0x00cc, 0x00cd, 0x00ce, 0x00cf] ],
   13 : [ [ 0x00d0, 0x00d1, 0x00d2, 0x00d3, 0x00d4, 0x00d5, 0x00d6, 0x00d7],  [ 0x00d8, 0x00d9, 0x00da, 0x00db, 0x00dc, 0x00dd, 0x00de, 0x00df] ]
}

    

#  seq CRI, ROB FEB type(0a 1b)    # TODO: type obsolete, since first a-, second b-list   
topo = {
    1 : [ [ 0, 0, 4, 0 ], [ 0, 0, 3, 1 ] ],   # 01Tr-3
    2 : [ [ 0, 0, 2, 0 ], [ 0, 0, 1, 1 ] ],   # 02Tr-3
    3 : [ [ 0, 1, 4, 1 ], [ 0, 1, 3, 0 ] ],   # 01Tl-4
    4 : [ [ 0, 1, 2, 1 ], [ 0, 1, 1, 0 ] ],   # 02Tl-3
    5 : [ [ 0, 2, 4, 0 ], [ 0, 2, 3, 1 ] ],   # 01Tr-4 
    6 : [ [ 0, 2, 2, 0 ], [ 0, 2, 1, 1 ] ],   # 03Tr-2
    7 : [ [ 0, 3, 4, 1 ], [ 0, 3, 3, 0 ] ],   # 01Tl-6
    8 : [ [ 0, 3, 2, 1 ], [ 0, 3, 1, 0 ] ],   # 02Tl-5
    9 : [ [ 0, 3, 0, 1 ], [ 0, 4, 4, 0 ] ],   # 03Tl-3
   10 : [ [ 0, 4, 3, 1 ], [ 0, 4, 2, 0 ] ],   # 01Tl-3 (cosy)
   11 : [ [ 0, 4, 1, 1 ], [ 0, 4, 0, 0 ] ],   # 03Tl-1
#    7 : [ [ 0, 3, 4, 1 ], [ 0, 3, 3, 0 ] ],   # 01Tl-6
#    8 : [ [ 0, 3, 2, 1 ], [ 0, 3, 1, 0 ] ],   # 02Tl-5
#    9 : [ [ 0, 3, 0, 1 ], [ 0, 4, 4, 0 ] ],   # 03Tl-3
#   10 : [ [ 0, 4, 3, 1 ], [ 0, 4, 2, 0 ] ],   # 01Tl-3 (cosy)
#   11 : [ [ 0, 4, 1, 1 ], [ 0, 4, 0, 0 ] ],   # 03Tl-1
   12 : [ [ 0, 1, 0, 0 ], [ 0, 1, 0, 0 ] ],   # pulser feb
   13 : [ [ 0, 2, 0, 0 ], [ 0, 2, 0, 0 ] ]    # pulser feb
}


# cri rob feb (from topo) to seq feb (from setup, single params)
crf2seq = {}
for seq, to in topo.items():
    for nf, f in enumerate(to):
        crf2seq[(f[0],f[1],f[2])] = [seq, nf] 

    
