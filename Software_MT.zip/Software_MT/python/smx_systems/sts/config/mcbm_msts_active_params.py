
import collections
             
par =  { 
         "f_ch_disc_en"         : {"row":   0, "col": 63, "lsb": 7, "mask": 0x80 , "type": 'd' },    # def
         "f_ch_i_disc"          : {"row":   0, "col": 63, "lsb": 6, "mask": 0x40 , "type": 'd' },    # def
         "f_ch_rng_sel"         : {"row":   0, "col": 63, "lsb": 4, "mask": 0x30 , "type": 'd' },    # def
         "f_ch_ext_pls_en"      : {"row":   0, "col": 63, "lsb": 3, "mask": 0x08 , "type": 'd' },    # def/tst
         "f_ch_sh_buf_en"       : {"row":   0, "col": 65, "lsb": 7, "mask": 0x80 , "type": 'd' },    # def
         "f_ch_rf_hl"           : {"row":   0, "col": 65, "lsb": 6, "mask": 0x40 , "type": 'd' },    # def
         "f_ch_gain_csa"        : {"row":   0, "col": 65, "lsb": 3, "mask": 0x38 , "type": 's' },    # def/cfg sts/much
         "f_ch_csa_en"          : {"row":   0, "col": 65, "lsb": 2, "mask": 0x04 , "type": 'd' },    # def
         "f_ch_disc_dis"        : {"row":   0, "col": 67, "lsb": 7, "mask": 0x80 , "type": 'd' },    # def
         "f_ch_disc_offset_dac" : {"row":   0, "col": 67, "lsb": 0, "mask": 0x3f , "type": 'd' },    # def
         "f_ch_trim_val"        : {"row":   0, "col":  1, "lsb": 0, "mask": 0xff , "type": 'cg' },    # cfg   c or u ???
         "f_ch_trim_offset"     : {"row":   0, "col": 68, "lsb": 0, "mask": 0xff , "type": 'u' },    # cfg   c or u ???
         "f_csa_front"          : {"row": 130, "col":  0, "lsb": 0, "mask": 0x3f , "type": 'c' },    # cfg
         "f_csa_rf"             : {"row": 130, "col":  1, "lsb": 0, "mask": 0x3f , "type": 'c' },    # cfg
         "f_cal_rng"            : {"row": 130, "col":  1, "lsb": 6, "mask": 0x40 , "type": 's' },    # sts/much
         "f_chrg_type"          : {"row": 130, "col":  2, "lsb": 5, "mask": 0x20 , "type": 's' },    # setup
         "f_en_csa_gl"          : {"row": 130, "col":  2, "lsb": 7, "mask": 0x80 , "type": 'd' },    # def
         "f_psc_rng"            : {"row": 130, "col":  2, "lsb": 4, "mask": 0x10 , "type": 'd' },    # def
         "f_ps_en"              : {"row": 130, "col":  2, "lsb": 6, "mask": 0x40 , "type": 'cg' },    # cfg/def
         "f_psc_bias"           : {"row": 130, "col":  2, "lsb": 0, "mask": 0x07 , "type": 'cg' },    # cfg/def
         "f_sh_bias"            : {"row": 130, "col":  3, "lsb": 0, "mask": 0x3f , "type": 'cg' },    # cfg/def
         "f_amp_cal"            : {"row": 130, "col":  4, "lsb": 0, "mask": 0xff , "type": 't' },    # def/tst
         "f_sh_slow_fs"         : {"row": 130, "col":  5, "lsb": 2, "mask": 0x0c , "type": 'c' },    # cfg
         "f_cal_grp"            : {"row": 130, "col":  5, "lsb": 0, "mask": 0x03 , "type": 't' },    # def/tst  
         "f_ref_curr_fast"      : {"row": 130, "col":  6, "lsb": 0, "mask": 0x3f , "type": 'd' },    # cfg/def
         "f_disc_th2_glob"      : {"row": 130, "col":  7, "lsb": 0, "mask": 0xff , "type": 'u' },    # cfg/def
         "f_vref_n"             : {"row": 130, "col":  8, "lsb": 0, "mask": 0x3f , "type": 'c' },    # cfg 
         "f_vref_p"             : {"row": 130, "col":  9, "lsb": 0, "mask": 0x3f , "type": 'c' },    # cfg
         "f_adc_vref_xdac_en"   : {"row": 130, "col": 10, "lsb": 7, "mask": 0x80 , "type": 'd' },    # def
         "f_vref_t_rng_2"       : {"row": 130, "col": 10, "lsb": 6, "mask": 0x40 , "type": 'cg' },    # def/cfg  
         "f_daq_en"             : {"row": 130, "col": 11, "lsb": 6, "mask": 0x40 , "type": 'o' },    # oper
         "f_cal_strobe"         : {"row": 130, "col": 11, "lsb": 7, "mask": 0x80 , "type": 't' },    # def/tst 
         "f_in_csap"            : {"row": 130, "col": 12, "lsb": 0, "mask": 0x3f , "type": 'c' },    # cfg/def
         "f_csa_back"           : {"row": 130, "col": 13, "lsb": 0, "mask": 0x3f , "type": 'c' },    # cfg
         "f_buf_csa"            : {"row": 130, "col": 14, "lsb": 3, "mask": 0x38 , "type": 'd' },    # def?
         "f_cas_csa"            : {"row": 130, "col": 14, "lsb": 0, "mask": 0x07 , "type": 'd' },    # def? 
         "f_buf_sh"             : {"row": 130, "col": 15, "lsb": 3, "mask": 0x38 , "type": 'd' },    # def?
         "f_cas_sh"             : {"row": 130, "col": 15, "lsb": 0, "mask": 0x07 , "type": 'd' },    # def
         "f_csa_bias_1v_sw"     : {"row": 130, "col": 16, "lsb": 6, "mask": 0x40 , "type": 'd' },    # def
         "f_csa_bias_1v"        : {"row": 130, "col": 16, "lsb": 0, "mask": 0x3f , "type": 'd' },    # def 
         "f_dac_thr1"           : {"row": 130, "col": 17, "lsb": 0, "mask": 0xff , "type": 'd' },    # def/tst
         "f_vref_t_rng"         : {"row": 130, "col": 18, "lsb": 6, "mask": 0xc0 , "type": 'cg' },    # cfg
         "f_vref_t"             : {"row": 130, "col": 18, "lsb": 0, "mask": 0x3f , "type": 'u' },    # cfg
         "f_diag_mux"           : {"row": 130, "col": 20, "lsb": 0, "mask": 0x07 , "type": 'o' },    # oper 
         "f_diag_ibias"         : {"row": 130, "col": 21, "lsb": 0, "mask": 0x3f , "type": 'd' },    # def/cfg/oper 
         "f_diag_thr"           : {"row": 130, "col": 22, "lsb": 0, "mask": 0xff , "type": 'o' },    # oper
         "f_alert_ack_rep_en"   : {"row": 192, "col":  3, "lsb": 6, "mask": 0x040 , "type": 'cg' },   # cfg/def
         "f_alert_ack_gen_en"   : {"row": 192, "col":  3, "lsb": 5, "mask": 0x020 , "type": 'cg' },   # cfg/def
         "f_tst_trg_max_en"     : {"row": 192, "col":  3, "lsb": 4, "mask": 0x010 , "type": 'cg' },   # cfg/def
         "f_ts_msb_auto_en"     : {"row": 192, "col":  3, "lsb": 3, "mask": 0x008 , "type": 'cg' },   # cfg/def
         "f_ts_dummy_hit_en"    : {"row": 192, "col":  3, "lsb": 2, "mask": 0x004 , "type": 'cg' },   # cfg/def
         "f_ts_ackfr_en"        : {"row": 192, "col":  3, "lsb": 1, "mask": 0x002 , "type": 'cg' },   # cfg/def
         "f_ch_mask_en"         : {"row": 192, "col":  3, "lsb": 0, "mask": 0x001 , "type": 'cg' },   # cfg/def
         "f_mask"               : {"row": 192, "col":  4, "lsb": 0, "mask": 0x3ffffffffffffffffffffffffffffffff , "type": 'u' },   # cfg/oper
         "f_ts_set_val"         : {"row": 192, "col": 14, "lsb": 0, "mask": 0x3fff , "type": 'o' },  # oper
         "f_tst_mode_0_en"      : {"row": 192, "col": 18, "lsb": 0, "mask": 0x001 , "type": 't' },   # def/tst
         "f_tst_mode_1_en"      : {"row": 192, "col": 18, "lsb": 1, "mask": 0x002 , "type": 't' },   # def/tst
         "f_tst_hit_1_div"      : {"row": 192, "col": 19, "lsb": 8, "mask": 0x700 , "type": 't' },   # def/tst
         "f_tst_hit_1_nrnd"     : {"row": 192, "col": 19, "lsb": 5, "mask": 0x0e0 , "type": 't' },   # def/tst
         "f_tst_hit_1_rate"     : {"row": 192, "col": 19, "lsb": 0, "mask": 0x01f , "type": 't' },   # def/tst
         "f_tst_trg_all_ch"     : {"row": 192, "col": 20, "lsb": 0, "mask": 0x001 , "type": 't' },   # def/tst
         "f_monitor_ref"        : {"row": 192, "col": 21, "lsb": 0, "mask": 0x001 , "type": 'd' },   # def/oper
         "f_af_thr"             : {"row": 192, "col": 23, "lsb": 0, "mask": 0x1ff , "type": 'c' },   # cfg 
         "f_af_cnt"             : {"row": 192, "col": 24, "lsb": 0, "mask": 0xfff , "type": 'r' },   # def/rd 
         "f_elink_mask_soft"    : {"row": 192, "col": 25, "lsb": 0, "mask": 0x01f , "type": 's' },   # cfg/setup
         "f_elink_mask_hard"    : {"row": 192, "col": 25, "lsb": 4, "mask": 0x3e0 , "type": 's' },   # def
         "f_em_thr"             : {"row": 192, "col": 29, "lsb": 0, "mask": 0x1ff , "type": 'c' },   # cfg
         "f_em_cnt"             : {"row": 192, "col": 30, "lsb": 0, "mask": 0xfff , "type": 'r' },   # def/rd
         "f_seu_cnt"            : {"row": 192, "col": 31, "lsb": 0, "mask": 0xfff , "type": 'r' },   # def/rd 
         "f_status"             : {"row": 192, "col": 27, "lsb": 0, "mask": 0x7ff , "type": 'o' },   # def/rd
         "f_status_mask"        : {"row": 192, "col": 28, "lsb": 0, "mask": 0x7ff , "type": 'cg' },   # cfg 
         "f_alert_ack_mask"     : {"row": 192, "col": 36, "lsb": 0, "mask": 0x7ff , "type": 'cg' },   # cfg
         "f_efuse_ctl"          : {"row": 192, "col": 32, "lsb": 0, "mask": 0x0ff , "type": 'o' },   # def/oper
       }


default =  { 
         "d_ch_disc_en"         : 1,
         "d_ch_i_disc"          : 0,
         "d_ch_rng_sel"         : 1,
         "d_ch_ext_pls_en"      : 0,
         "d_ch_sh_buf_en"       : 1,
         "d_ch_rf_hl"           : 1,
         "d_ch_gain_csa"        : 6,
         "d_ch_csa_en"          : 1,
         "d_ch_disc_dis"        : 0,
         "d_ch_disc_offset_dac" : 36,
         "d_ch_trim_val"        : 128,
         "d_ch_trim_offset"     : 0,
         "d_csa_front"          : 7,  # 31 
         "d_csa_rf"             : 20,
         "d_cal_rng"            : 0,
         "d_chrg_type"          : 1,       # arbitrary default: electrons 
         "d_en_csa_gl"          : 1,
         "d_psc_rng"            : 0,
         "d_ps_en"              : 0,       # fast reset: disabled
         "d_psc_bias"           : 3,
         "d_sh_bias"            : 31,
         "d_amp_cal"            : 0,
         "d_sh_slow_fs"         : 1,      # or 0 as default? 
         "d_cal_grp"            : 0,
         "d_ref_curr_fast"      : 32,
         "d_disc_th2_glob"      : 25,
         "d_vref_n"             : 25,
         "d_vref_p"             : 57,
         "d_adc_vref_xdac_en"   : 1, 
         "d_vref_t_rng_2"       : 0,       # bit 2 only of vref_t range
         "d_daq_en"             : 0,       # global_gate_backend
         "d_cal_strobe"         : 0,    
         "d_in_csap"            : 5,   # 30 ??!?     
         "d_csa_back"           : 7,   # 31
         "d_buf_csa"            : 3,
         "d_cas_csa"            : 1,
         "d_buf_sh"             : 3,
         "d_cas_sh"             : 3,
         "d_csa_bias_1v_sw"     : 1,
         "d_csa_bias_1v"        : 27,
         "d_dac_thr1"           : 0,      # 0, 7, nn????? TODO: confirm with KK
         "d_vref_t_rng"         : 1,      # coarsest range; approx. 560e / LSB
         "d_vref_t"             : 58,
         "d_diag_mux"           : 6,      # arbitrary default: vTemp
         "d_diag_ibias"         : 31,
         "d_diag_thr"           : 128,
         "d_alert_ack_rep_en"   : 0,
         "d_alert_ack_gen_en"   : 0,
         "d_tst_trg_max_en"     : 0,
         "d_ts_msb_auto_en"     : 0,
         "d_ts_dummy_hit_en"    : 0,
         "d_ts_ackfr_en"        : 0,
         "d_ch_mask_en"         : 1,
         "d_mask"               : 0,      # all channel enabled
         "d_ts_set_val"         : 0,
         "d_tst_mode_0_en"      : 0,
         "d_tst_mode_1_en"      : 0,
         "d_tst_hit_1_div"      : 1,
         "d_tst_hit_1_nrnd"     : 0,
         "d_tst_hit_1_rate"     : 1,
         "d_tst_trg_all_ch"     : 0,
         "d_monitor_ref"        : 0, 
         "d_af_thr"             : 255,
         "d_af_cnt"             : 0,
         "d_elink_mask_soft"    : 1,      # first uplink as default which wil work for all FEB types
         "d_elink_mask_hard"    : 0,
         "d_em_thr"             : 255,
         "d_em_cnt"             : 0,
         "d_seu_cnt"            : 0,
         "d_status"             : 0,
         "d_status_mask"        : 1023,
         "d_alert_ack_mask"     : 1023,
         "d_efuse_ctl"          : 0
       }

    
cfg_l =  [
         "c_130",
         "c_chrg_type",
         "c_csa_front",         
         "c_csa_rf",            
         "c_ps_en",             
         "c_psc_bias",          
         "c_sh_bias",           
         "c_amp_cal",           
         "c_sh_slow_fs",        
         "c_ref_curr_fast",     
         "c_disc_th2_glob",     
         "c_vref_n",            
         "c_vref_p",            
         "c_vref_t_rng_2",      
         "c_daq_en",            
         "c_in_csap",           
         "c_csa_back",          
         "c_vref_t_rng",        
         "c_vref_t",
         "c_192",
         "c_alert_ack_rep_en",  
         "c_alert_ack_gen_en",  
         "c_tst_trg_max_en",    
         "c_ts_msb_auto_en",    
         "c_ts_dummy_hit_en",   
         "c_ts_ackfr_en",       
         "c_ch_mask_en",        
         "c_mask",              
         "c_af_thr",            
         "c_elink_mask_soft",   
         "c_elink_mask_hard",   
         "c_em_thr",            
         "c_status",            
         "c_status_mask",       
#         "c_alert_ack_mask",    
       ]


cfg_l2 =  [
         "c_130",
         "c_chrg_type",
         "c_csa_front",         
         "c_csa_rf",            
         "c_ps_en",             
         "c_psc_bias",          
         "c_sh_bias",           
         "c_amp_cal",           
         "c_sh_slow_fs",        
         "c_ref_curr_fast",     
         "c_disc_th2_glob",     
         "c_vref_n",            
         "c_vref_p",            
         "c_vref_t_rng_2",      
         "c_daq_en",            
         "c_in_csap",           
         "c_csa_back",          
         "c_vref_t_rng",        
         "c_vref_t",
         "c_192",
         "c_alert_ack_rep_en",  
         "c_alert_ack_gen_en",  
         "c_tst_trg_max_en",    
         "c_ts_msb_auto_en",    
         "c_ts_dummy_hit_en",   
         "c_ts_ackfr_en",       
         "c_ch_mask_en",        
         "c_mask",              
         "c_af_thr",            
         "c_elink_mask_soft",   
         "c_elink_mask_hard",   
         "c_em_thr",            
         "c_status",            
         "c_status_mask",       
         "c_alert_ack_mask",    
       ]

    
