import sys
import time
import os
import numpy as np
import logging as log

class sts_Module_directory():
	
	module_path = 'module_files/'
	module_name = ""
	date  = time.strftime("%y_%m_%d_%H_%M_%S")
	
	def __init__(self, module_id, sensor_size, mic_length):
		self.module_id = module_id
		self.sensor_size = sensor_size
		self.mic_length = mic_length
		self.module_directory = module_path + module_id
		
	
	def check_ModuleDir_exists(self):
		# checking if directory exists and creating 
		if (os.path.isdir(module_directory) == True):
		  print "This module directory already exists"
		else:
		  # creating the module files directory
		  try:
			 os.makedirs(module_directory)
		  except OSError as e:
			 if e.errno != errno.EEXIST:
				raise
			 else:
				print "Succesfully created Module directory %s:" + (module_path)
		
		# Creating trim and pscan files directory 
		try:
			os.makedirs(module_directory + "/" + "pscan_files")
			os.makedirs(module_directory + "/" + "trim_files")
		except OSError as e:
			if e.errno != errno.EEXIST:
				raise
			else:
				print "Succesfully created trim_files and pscan_files directories inside %s:" + (module_directory)
	
	def creating_Data_file(self, module_name):
		datafile = open(module_directory + "/" + module_name + "_data.dat","w+")
		
	def creating_Log_file(self, module_name):
		logfile = open(module_directory + "/" + module_id + "_log.log","a")
	
	def check_ModuleDatafile_exists(self):
		# checking if data file exists
		if (os.path.isfile(module_directory + "/" + module_id + "_data.dat") == True):
		  print "Data file already exists. Would you like to re-write it (Y/N):"
		  writing_flag = raw_input()
		  if ( writing_flag == 'N' or writing_flag == 'No' or writing_flag == 'n' or writing_flag == 'no'):
			 module_name = module_id + "_" + date        # changing file name with different date
			 print "Data file will be created with the following name: %s" %(module_directory + "/" + module_name + "_data.dat")
		  else:
			 module_name = module_id
		else:
		  module_name = module_id
		  print "Data file does not exists & it will be created with the following name: %s"  %(module_directory + "/" + module_name + "_data.dat")
		
		# creating data file and initializing it
		creating_Data_file(module_name)
		init_ModuleDatafile()
		
		creating_Log_file(module_name)
		init_ModuleLogfile()
	
	def init_ModuleDatafile(self):
		# initializing data file
		datafile.write("MODULE_ID: ")
		datafile.write(module_id)
		datafile.write("\n")
		datafile.write("TEST_DATE: ")
		datafile.write(date)
		datafile.write("\n")
	
	def init_ModuleLogfile(self):
		# initializing log file
		logfile.write(date)
		logfile.write("\t")
		logfile.write("MODULE_ID:")
		logfile.write("\t")
		logfile.write(module_id)
		logfile.write("\n")
		
	def close_ModuleLogfile(self):                                                                   
		# ending testing & closing data and log files
		logfile.write(date)
		logfile.write("\t")
		logfile.write("Ending test sequence")
		logfile.write("\n")
		logfile.close()
	
	def close_ModuleDatafile(self):
		if (os.path.isfile(module_directory + "/" + module_name + "_data.dat") == True):
			datafile.close()
			return True
		else:
			return False
	
	
	def write_rdata (self, itype,reg0,value):    # write_rdata(type of info (reg (r) or data (d)), register number, value)
		if (itype == "r"):
		  datafile.write(reg0)
		  datafile.write(" : ")
		  datafile.write(value)
		  datafile.write("\n")
		else:
		  datafile.write(value)
		  datafile.write("\n")

	def write_log(self, info):                    # write_info in the log file (info)
		logfile.write(date)
		logfile.write("\t")
		logfile.write("[INFO]")
		logfile.write("\t")
		logfile.write(info)
