import sys
import time
import logging as log
import json
import pickle
import argparse
import collections
import glob
from datetime import datetime
import configparser
import pprint

import hctsp
import agwb
#from cbm_setup import configure_cri003_00

#from cri_smx.smx import SmxSlr

from sts_asic import Smx as SmxD
from smx_conf import SmxConf

import msts_defs as smc

import mcbm_msts_active_single_par as e_spar
import mcbm_msts_active_params as e_par
import mcbm_msts_active_conf as e_conf

import mcbm_msts_active_setup as e_setup

from smx_util import smxTrim

par = getattr(e_par, "par")
default = getattr(e_par, "default")
cfg_l = getattr(e_par, "cfg_l")
cfg_l2 = getattr(e_par, "cfg_l2")
topo = getattr(e_setup, "topo")
crf2seq = getattr(e_setup, "crf2seq")
calib_dict = getattr(e_conf, "calib_feb")


# collect info on script run time -------------------------------
exe_start_time = time.time()

# Get config data ------------------------------------------------
# Tod: check to which extend needed here or only in getSmxList()

import mcbm_msts_active_setup as e_setup
setup = getattr(e_setup, "setup")
setup_modules = getattr(e_setup, "setup_modules")
geom = getattr(e_setup, "geom")
topo = getattr(e_setup, "topo")
asics = getattr(e_setup, "asics")

import mcbm_msts_active_conf as e_conf
calib = getattr(e_conf, "calib")
config = getattr(e_conf, "config")
active = getattr(e_conf, "active")


class MstsOpMan():

    def __init__(self, c, config_file: str ):
        self.log = None
        self.parser = None
        self.hm = None
        self.smx_list = []
        self.n_max = 3
        self.test_mode = True
        self.smconf = SmxConf(par)

        self.c = c
        self.config_file = config_file

        # read config File
        self.config = configparser.ConfigParser()
        self.config.read(config_file)
        conf = self.config["default"]

        self.iseq = int(conf['iseq'])

        self.config_no = int(conf['yaml_no'])
        self.yaml_file = "nn"
        self.crobs = json.loads(conf['crobs'])
        self.sys_id = int(conf['sys_id'], 16)
        self.channel_mask = conf['channel_mask']
        self.sync_src = int(conf['sync_src'])
        self.dump_level = int(conf['dump_level'])

        
        self.p_path = conf['p_path']
        self.dumpfile_pickle = conf['dumpfile_pickle']
        self.daq_en = int(conf['daq_en'])
        self.trim_tag = conf['trim_tag']
        self.trim_path = conf['trim_path']        


        ## Enable CROBs
        #for cr in self.crobs:
        #    c.enable_crob(smc.cslr[cr]['iface'])                      # ToDo: wnat eactly does "enable_crob" do?
            ## [islr, ichan] = c.get_idx_by_mtp(smc.cslr[cr]['iface'])   # this line is obsolete ??!!!

        ## Set equipment IDs eq_id
        #for islr in [0, 1]:
            #for icrob in c.slrs[islr].hslr.crobs.keys():
                #eq_id = 0x1000 + icrob + 3*islr + 1
                #log.info("Set Eq_Id %s   (islr %d    icrob %d)", hex(eq_id), islr, icrob)
                #c.slrs[islr].dproc[icrob].reg.crob_ctrl.flim_eqid.writef(eq_id)
                #c.slrs[islr].dproc[icrob].reg.crob_ctrl.flim_sysid.writef(self.sys_id)

        #self.slrs = []
        #self.dprocs = []
        #for islr in [0, 1]:
            #self.slrs.append(c.slrs[islr])
            #for icrob in c.slrs[islr].hslr.crobs.keys():
                #self.dprocs.append(c.slrs[islr].dproc[icrob])
                #log.info("DPROC   slr %d  icrob %d ", islr, icrob)

    def init_conf(self):
        pass

    def init_smx_topo_list(self) -> list:
        smx_list = []  # flat list of all asics from SLR initialization
        # loop over all asics from HCTSP init

        # ToDo: make an "slr_active" list from CROB enable above and use for all loops over slrs
        # even better: list of "cri/slr"
        for islr in [0, 1]:
            for icrob in self.c.slrs[islr].hslr.crobs.keys():
                for ifeb in range(len(self.c.slrs[islr].hslr.crobs[icrob].febs)):
                    for ismx in range(len(self.c.slrs[islr].hslr.crobs[icrob].febs[ifeb].asics)):
                        sx = self.c.slrs[islr].hslr.crobs[icrob].febs[ifeb].asics[ismx]
                        # also set the ASICs slr number which was not known previously
                        # ToDo: check if slr available from elsewhere
                        sx.slr = islr
                        smx_list.append(sx)
        return smx_list

    def init_smx_list(self, smx_list_topo: list, mode: int = smc.SMX_CONF, adev: list = None):
        """ fully initializes Smx objects instantiated from the slr-rob-feb-asic chain
            the methods basically maps the smx objects initialized from the slr chain to the smx
            structure defined in the STS setup files
            It then fully initializes all Smx attributes from the STS configuration and
            adds them to the smx_list of OpMan
            Note:
            
               1) the method only fully initializes and adds to the list all Smx that are marked
                  as "active" in the conf file
               2) this method has to endure proper mapping and consistency of all the various
                  coordinate systems (cri-slr-rob-feb-asic), (station-quadrant-ladder-module-feb-asic),
                  (module-feb-asic)
        args: smx_list_topo:   list of asics from the uplink scan
              mode:  init mode - from CONFIG files or from PICKLEd Smx objects (TODO: decide
                                   if the second way is obsolete)
              adev:  flag; if set, inits and appends only Smx objects that match "crfa" ( cri,rob,feb,asic)
        returns: list of active -and fully initialized- smx objects
        """
        log.info("smx_list_topo: %d asics", len(smx_list_topo))

        if adev is None:
            dev_flag = False
        else:
            dev_flag = True
            assert len(adev) == 4

        active_list = active

        # TODO: implement recovery from pickle for slr/hctsp mode
        #   basic idea: recover to smx list; map to smx_list_topo, copy to smx_list_topo
        #
        # original:
        # if mode == smc.SMX_PICK:
        #     smx_list = self.get_smx_list_pickle()
        #     self.smx_list = smx_list
        #     return smx_list

        # instantiate all asics
        #   from modules in geom and active
        #     cross check with topo
        #    from asics
        # set pars:
        #   default on instantiation from default
        #   setup on instantiation ( chrg_type, elink mask) from setup
        #   cg from  default ( no support for configs yet )
        #   configuration from  config or config_built    ( asic specific default mask? )
        #   trim from calib
        #   tuning (vref_t, mask) from scripts

        # TODO: review code below; clearer names,..

        smx_list = []
        n_asic_found = 0
        n_asic_lost = 0
        adev_found = False

        amatch_map = [[["_" for a in range(8)] for f in range(2)] for mod in range(14)]   # ToDo: hardcoded number of modules

        for seq, act in active_list.items():                     # loop over modules in active
            for al in [0, 1]:                 # asic list of 1st, 2nd feb
                a_asics = active_list[seq][al]
                ftype = setup[seq][al][2]    # get module type
                chrg = setup[seq][al][1]
                f = topo[seq][al]
                # a = asics[seq][al]     not used?
                # f = topo[seq][smc.fno[ftype]]
                # a = asics[seq][smc.fno[ftype]]

                for n, aa in enumerate(a_asics):
                    if aa == 1:                      # active asic
                        clog = topo[seq][al][1]
                        flog = topo[seq][al][2]
                        alog = asics[seq][al][n]
                        # clog = topo[seq][smc.fno[ftype]][1]
                        # flog = topo[seq][smc.fno[ftype]][2]
                        # alog = asics[seq][smc.fno[ftype]][n]

                        # TODO: below just dummy !!!!!!
                        # asic_dict = { "asic": 1 }

                        #  From the smx_list_topo, instead the proper smx (instantiated in StsSlr and children)
                        #    has to be found and configured
                        nsmx = None
                        for smxt in smx_list_topo:
                            if seq == 3:
                                if smxt.slr == smc.cslr[f[1]]['slr'] and smxt.crob_idx == smc.cslr[f[1]]['idx'] and \
                                   (smc.dl2feb[int(smxt.dlink/2)] == f[2]) and smxt.chip_address == smc.ahw[ftype][n]:
                                   # log.info(" MATCH2")
                                   pass
                            if smxt.slr == smc.cslr[f[1]]['slr'] and smxt.crob_idx == smc.cslr[f[1]]['idx'] and \
                               (smc.dl2feb[int(smxt.dlink/2)] == f[2]) and smxt.chip_address == smc.ahw[ftype][n]:
                                nsmx = smxt
                                # log.info("           %d %d %d %d %d",smxt.slr, smxt.crob_idx, f[1], f[2], smxt.chip_address)
                                n_asic_found += 1
                                log.debug(f" {seq}  asic (c f a)  {clog} {flog} {alog}  active")

                                break
                        if nsmx is None:
                            n_asic_lost += 1
                            log.debug("       No Match(r f a): %d %d %d (%d)", f[1], f[2], n, smc.ahw[ftype][n])
                            amatch_map[seq][al][n] = "x"
                            continue
                        else:
                            log.debug("       Match(r f a): %d %d %d (%d)", f[1], f[2], n, smc.ahw[ftype][n])
                            log.debug(f"{n} {al} {seq}" )
                            amatch_map[seq][al][n] = "o"
                        # end of the mapping: nsmx is now one of the
                        nsmx.a_id = 16*seq + 8*al + n
                        nsmx.aseq = n
                        nsmx.mseq = seq
                        nsmx.hw_addr = smc.ahw[ftype][n]
                        nsmx.ftype = ftype     # FEB a or b
                        nsmx.chrg = chrg  # p or n
                        # geom
                        s = geom[seq]
                        nsmx.module = s[3]
                        nsmx.ladder = s[2]
                        nsmx.quadrant = s[1]
                        nsmx.station = s[0]
                        # topo
                        nsmx.cri = f[0]
                        nsmx.rob = f[1]
                        nsmx.feb = f[2]
                        nsmx.set_stsm(self)

                        if dev_flag and nsmx.cri == adev[0] and nsmx.rob == adev[1] and nsmx.feb == adev[2] and nsmx.aseq == adev[3]:
                            # long condition
                            adev_found = True

                        nsmx.chrg_type = smc.cno[chrg]

                        # set asic trim file and "disc_th2_glob",  "vref_n", "vref_p" from trim 
                        otrim =  smxTrim(nsmx, calib_dict)
                        nsmx.disc_th2_glob = otrim.disc_th2_glob
                        nsmx.vref_n = otrim.vref_n
                        nsmx.vref_p = otrim.vref_p
                        nsmx.trimfile = otrim.trimfile_tag
                        nsmx.trim_vref_t = otrim.vref_t
                        
                        # for a_cal in calib:     # trim
                        #    if a_cal[0] == nsmx.a_id:
                        #        nsmx.trim = a_cal[1]
                        nsmx.func_to_reg(smc.R_INI)           # ToDo: check if this will overwrite the above settings (vref_p/n etc.)
                        nsmx.func_to_reg(smc.R_ACT)
                        if not dev_flag or adev_found:
                            smx_list.append(nsmx)
                            adev_found = False
                    else:                                               # ASIC inactive
                        clog = topo[seq][smc.fno[ftype]][1]
                        flog = topo[seq][smc.fno[ftype]][2]
                        alog = asics[seq][smc.fno[ftype]][n]
                        log.debug(f" asic {n} (c f a) {clog} {flog} {alog} inactive")
        log.info("SLR ASIC mappping: %d asics match  \t %d asics NO match", n_asic_found, n_asic_lost )
        for mod in range(1, 14):
            m_str = str(mod) + ":\t\t"
            for feb in range(2):
                m_str += "\t\t"
                for asic in range(8):
                    m_str += amatch_map[mod][feb][asic] + " "
            log.info(f"{m_str}")
        if n_asic_lost > 0:
            log.warning(f"{n_asic_lost} ASICs do not match!")
        if n_asic_found == 0:
            log.error(f"No matching ASICs found! This should not happen and will lead to subsequent errors! Exiting..")
            exit()   
        # set trims
        for nsmx in smx_list:
            if nsmx.a_id in calib:
                nsmx.trim = calib[nsmx.a_id]

        self.smx_list = smx_list
        return smx_list

    # --------------------------------------------------------------------------------------------------------------
    # --------------------------------------------------------------------------------------------------------------
    # --------------------------------------------------------------------------------------------------------------
    # --------------------------------------------------------------------------------------------------------------
    # --------------------------------------------------------------------------------------------------------------

    def set_smx_list(self, smx_list):
        self.smx_list = smx_list 

    # various init versions
    def init_hw(self, iseq: int = -1):    # e.g. DoInitSequence(I_CROB+I_FILE+I_SYNC)
        if iseq == -1:
            iseq = self.iseq
        log.info(f"HW init sequence no {iseq}") 
        if iseq == 1 or iseq == 3:
            if iseq == 1:
                log.warning("INit from file without link sync not implemented yet!! Sync is executed ( iseq = 3)")
                restore_file = "cfg/cfg_"+str(self.config_no)+".yaml"
                self.c.init_soft(filename=restore_file)
                self.c.init_sync()
        elif iseq == 7:
            restore_file = "cfg/cfg_"+str(self.config_no)+".yaml"
            self.c.init_hw(filename=restore_file)
            self.c.init_sync()
        elif iseq == 11 or iseq == 15:
            if iseq == 11:
                log.warning("scan with CROB power cycle not implemented yet!! CROB pwr cycle is done (iseq = 15) ")
            with open('SCAN_NO') as file:
                scan_no = int(file.read())
            with open('SCAN_NO', 'w' ) as file:
                file.write(str(scan_no+1))
            save_file = "cfg/cfg_"+str(scan_no)+".yaml"
            self.c.init_hw()
            self.c.save_config(save_file)
            self.c.init_sync()
        else:
            log.warning(" Init sequence %d not supported. Do nothing", iseq)

        smx_topo_list =  self.init_smx_topo_list()
        self.init_smx_list(smx_topo_list, smc.SMX_CONF)

    # ToDo implement this in the cri_smx
    def sync_elink(self):
        for slr in self.c.slrs:
            slr.hslr.resync_link()

    # FEE Config
    # Full onfiguration of FEE except for ADC trims
    def fee_config(self):
        log.info("--------\n  Full FEE Register Configuration without Trims\n----------------------------------------")

        smx_list = None

        # fill registers from -default- functions  -------------------------------
        self.func_to_reg(smc.R_ACT, smx_list)

        # write and readback all registers to asics  -------------------
        self.write_reg_all(smx_list)

        # Set some single paramters
        # write channel masks -----------------------------------------
        self.set_channel_masks(self.channel_mask, smx_list)

        # set single config param from single_par.py  ------------------
        s_par_list = [ "vref_t", "disc_th2_glob", "csa_front", "csa_back" ]
        for s_par in s_par_list:
            self.conf_s_par(s_par, smx_list=smx_list)

        # reset alerts and status
        self.reset_alert_and_status()

        # reset test modes
        self.reset_test_mode()

        # enable GlobalGate --------------------------------------------
        self.conf_s_par("daq_en", self.daq_en, smx_list)

    #   do the most frequently changing FEE settings
    #    this is fast and can be done in each script execution or run start
    def fee_set_mask_vreft_icsa(self):
        log.info(f"Set channel mask {self.channel_mask}")
        self.set_channel_masks(mask=self.channel_mask, smx_list=self.smx_list)

        log.info("Set Vreft")
        self.conf_s_par("vref_t", smx_list=None)
        log.info("Set dics_th2_glob")
        self.conf_s_par("disc_th2_glob", smx_list=self.smx_list)
        log.info("Set I_CSA")
        self.conf_s_par("csa_front", smx_list=None)
        self.conf_s_par("csa_back", smx_list=None)

    # set FEE discriminator trim values
    def fee_set_trim(self):
        log.info(" --- Set Trim Values --------------")
        self.set_trim(smx_list=None)

    # synchronize all ASIC timestamp counters of the CRI to the CRI/SLR timestamps
    def ts_sync(self):
        # the SMX TS values are sync'ed to the command_cycle_timestamp, which is the system timestamp with the
        #   granularity of the downlink frames, therefore everything below is in units of clk40 unless mentioned

        # SMX TS preset value in units of clk320. Note for TS settings: LSB cannot be SET
        ts_smx_pre = 0
        # offset to ts_smx_pre in clk320 units to approximately account for DL command (2x15 clk40 cycles) and
        #    signal propagation delays (order of 200ns = 8 clk40 cycles)  ==> approx. 38 clk40 or 304 clk320 cycles
        ts_smx_offset = 304
        # LCM of 2048 (smx TS cycle) and 15 (DL frame cycle); both in 40 MHz clk units. After this number of 40 MHz
        # clock cycles, DL frames and SMX TS are again in same phase. Is 768 us    ( LCM: least common multiple )
        smx_ts_dl_cycle = 30720
        # number of smx_ts_dl_cycles in the future to define the time when SMX TS are set;  arbitrary value,
        #  high enough to allow for execution of all code below;    2000 ==> 1.526 sec
        n_cycle_advance = 2000
        # number of 40  MHz clock cycles per downlink frame
        dl_cycle = 30

        log.info("Sync SMX Timestamps")

        # write TS preset value ts_smx_pre to all smx; use an (SLR) broadcast write
        #  DL frame cycles of all ASICs are in sync., therefore no individually adjusted preset values
        for islr in [0, 1]:
            self.c.slrs[islr].hslr.write(192, 14, (ts_smx_pre + ts_smx_offset) % 16384, chip_address=0x0f)

        # search for point in future where "smx TS preset" is aligned with DL frame TS
        for islr in [0, 1]:
            slr = self.c.slrs[islr]

            # get "current" command_cycle TS
            # command_cycle_ts with 40MHz  -> this means command cycle is aligned with 40 MHz clock!?!
            hm = slr.hmaster
            cycle_ts_0 = hm.h.command_cycle_timestamp_0.readb()
            cycle_ts_1 = hm.h.command_cycle_timestamp_1.readb()
            cycle_ts = cycle_ts_1() << 32 | cycle_ts_0()

            # ts_smx_pre = 8 * (cycle_ts % 2)      #  Wrong - creates an arbitrary ts_smx_pre depending on cycle_ts !?!
            ts_smx_pre_40 = (ts_smx_pre >> 3) & 0x7ff    # ts_smx_pre in 40MHz granularity,
            if (ts_smx_pre_40 % 2) !=  (cycle_ts % 2):   # accounts for fact that cycle_ts sometimes shows odd values
                ts_smx_pre_40 += 1                       # was not needed in July 2021 ?!?!

            # determine next point in time (units of downlink cycles) where downlink cycles and smx TS preset coincide
            #   TODO: solve analytically for next_coinc_cycle:  (cycle_ts + next_coinc_cycle*15) % 2048 = ts_smx_pre_40
            #            ==> non-homogeneous linear Diophantine equation
            #    for the moment we just loop over all possible values
            next_coinc_cycle = 1
            while True:
                cycle_ts_future = cycle_ts + next_coinc_cycle * dl_cycle
                if cycle_ts_future & 0x7ff == ts_smx_pre_40:
                    break
                next_coinc_cycle += 1

            # determine future sync time based on next_coinc_time and a multiple of coinc_cycle which is enough advanced
            #  in the future  ("enough" for all actions from cycle_ts read to the scheduling of the absolute time
            #     smx TS synchronization )
            abs_time_sync = (cycle_ts + next_coinc_cycle * dl_cycle + n_cycle_advance * smx_ts_dl_cycle)
            abs_time_sync_32 = abs_time_sync % 2**32
            # time deterministic SLR broadcast of TS set command
            slr.hslr.write(192, 15, 0xff, chip_address=0x0f, timestamp=abs_time_sync_32, tc_slot=1)
            log.info(f"cycle_ts {cycle_ts}  mod {cycle_ts%15}     next_coinc {next_coinc_cycle}    ")
            log.info(f" abs_time_sync   {abs_time_sync}    Sync in {round((abs_time_sync-cycle_ts)*25/1000)/1000 } ms")

# 3456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
#        1         2         3         4         5         6         7         8         9        10        11        12

    # ---- Readout ------

    # prepare CRI readout
    def prep_readout(self):

        #  SMX readout preparation
        log.info("Disable SMX Readout")
        self.disable_daq()
        log.info("Disable SMX test modes")
        self.reset_test_mode()

        # DPROC readout preparation
        # we want any data coming to dproc before it is configured
        log.info("Disabling elinks")
        for dproc in self.dprocs:
            dproc.elink_enable_mask(0xffff_ffff_ffff_ffff, 0x0)

        # make sure that the mcs generation is stopped
        log.info("Disable mcs generation")
        for slr in self.slrs:
            slr.dproc_comm.configure_mcs(0xffff_ffff_ffff_ffff, 0xffff_ffff_ffff_ffff, 100)

        # reset output fifo
        # just to make sure that flim doesn't get garbage from previous mcs
        log.info("Reset outputfifo")
        for slr in self.slrs:
            slr.dproc_comm.reset_outfifo()

        # make sure that the data comes from elinks, not cri's data generator
        log.info("Disabling datagen")
        for slr in self.slrs:
            slr.dproc_comm.configure_smx_datagen(2**4)
        for dproc in self.dprocs:
            dproc.use_smx_datagen(0)

        # this should set smxtimer located in dproc module to a value equivalent to current system time
        # the smxtimer works in 160MHz, so its value is 4 times bigger than equivalent system time
        # 1.07.2021 - not sure if this procedure works correctly
        log.info("Setting the dproc timer")
        log.info(f" SYSTIME RE BLOCK{self.c.get_system_time()}")
        for slr in self.slrs:
            slr.dproc_comm.sync_cri_timer_blocking(time_advance_sec=2)

        # I didn't see garbage on unused elinks (yet?)
        # at that point the data pass to dproc modue
        # but mcs generation is still disabled (by setting unreasonable start/stop threshold)
        # so the data is dropped after most of the sorting
        log.info("Enabling all elink")
        for dproc in self.dprocs:
            dproc.elink_enable_mask(0xffff_ffff_ffff_ffff, 0xffff_ffff_ffff)

    # start CRI readout
    def start_readout(self):
        # ToDo: cross check with daemon start

        # ToDo: check where to put these definitions
        bins = 400  # 400
        bin_width = 3200
        mcs_duration = bins * bin_width  # in ns
        start_sec = 3

        log.info("Enable FLIM Readout")

        # enable SMX readout
        log.info("Enable SMX Readout")
        self.enable_daq()

        current_systime = self.c.get_system_time()
        mcs_starttime = int(25*current_systime + start_sec * 1e9)  # in ns
        mcs_starttime_bin = ((mcs_starttime + mcs_duration ) // mcs_duration) * mcs_duration   #
        log.info("STARTTIME %d", mcs_starttime)
        log.info(f"systime {current_systime} clk40\t  starttime_bin  {mcs_starttime_bin} ns  \
                    start_delay {mcs_starttime_bin - 25* current_systime} ns")
        for slr in self.slrs:
            slr.dproc_comm.configure_mcs(mcs_starttime_bin, 0xffff_ffff_ffff_ffff, bins)

    # stop CRI readout
    def stop_readout(self):
        # ToDo: check where to put these definitions
        bins = 400  # 400
        bin_width = 3200
        mcs_duration = bins * bin_width  # in ns

        start_sec = 2
        stop_sec = 3

        current_systime = self.c.get_system_time()
        mcs_starttime = int(25*current_systime + start_sec * 1e9)  # in ns
        mcs_stoptime = int(25*current_systime + stop_sec * 1e9)    # in ns
        mcs_starttime_bin = ((mcs_starttime + mcs_duration ) // mcs_duration) * mcs_duration   #
        mcs_stoptime_bin = ((mcs_stoptime + mcs_duration ) // mcs_duration) * mcs_duration   #

        log.info("Stop run %d", mcs_starttime)

        log.info(f"systime {current_systime} clk40\t  starttime_bin  {mcs_starttime_bin} ns stoptime_bin\
                {mcs_stoptime_bin} ns   start_delay {mcs_starttime_bin - 25* current_systime} ns")
        for slr in self.slrs:
            slr.dproc_comm.configure_mcs(mcs_starttime_bin, mcs_stoptime_bin, bins)
            # slr.dproc_comm.configure_mcs(mcs_starttime_bin, 0xffff_ffff_ffff_ffff, bins)

    # do time synchronization of CRI to TFC or host UTC
    def cri_time_sync(self):
        # Todo: define somewhere UTC, MASTER
        sync_src = self.sync_src
        if sync_src == smc.UTC:
            self.c.set_UTC_system_time()
            log.info("Time Sync to UTC done!")
        elif sync_src == smc.MASTER:
            self.c.dca.tfc.SyncReset()
            time.sleep(.1)
            tfc_sync_state = self.c.dca.tfc.SyncState()
            if tfc_sync_state == 1:
                log.info("Time Sync to master ok!")
            else:
                log.error("Time Sync to master failed!")
                exit()
        else:
            log.warning("Invalid Sync source %s. No TFC time sync done!", str(sync_src()))

    # --- Checks and Readbcks ------

    # check FEE configuration
    def fee_check(self):
        log.warning("fee_check not implemented yet! Do nothing..")
        for smx in self.smx_list:
            pass
            # ToDo

    # readback vddm values
    def read_vddm(self):
        log.info("Read Vddm")
        self.read_vddm_formatted(offset=1200, vddm_range=100)

    # --- Var Tests ------
    def misc_tests(self):
        # ToDo: review and eventually split into separate tests
        log.warning("Misc. Test not yet migrated from msts_test_1.py!!!")

    # test ADC counter with noise
    # add one pulser asic as default
    def test_adc_counter(self, a_list: list = [], cnt_time: int = 1):
        # a_list format:  list of [slr, rob, feb, asic]
        #    alist = [
        #       [1,2,0,2]
        #     ]
        sx_list = []
        # pulser asics
        # sx_p10 = self.c.slrs[1].hslr.crobs[2].febs[0].asics[2]  # TODO: which two asics are pulser?
        # sx_p11 = self.c.slrs[1].hslr.crobs[2].febs[0].asics[4]  # TODO: which two asics are pulser?
        # sx_p00 = self.c.slrs[0].hslr.crobs[1].febs[0].asics[0]
        # sx_p01 = self.c.slrs[0].hslr.crobs[1].febs[0].asics[1]
        # sx_list.append(sx_p10)

        for smx in self.smx_list:
            for al in a_list:
                if smx.slr == al[0] and smx.rob == al[1] and smx.feb == al[2] and smx.aseq == al[3]:
                    sx_list.append(smx)
                    break

        for n, sx in enumerate(sx_list):
            if sx is None:
                continue
            sx.conf_func("vref_t", 62)
            sx.conf_func("ch_disc_offset_dac", 30)
            self.disable_daq()
            sx.reset_adc_counter()
            # sx.read_adc_counter()
            log.info("")
            self.enable_daq()
            time.sleep(cnt_time)
            self.disable_daq()
            sx.read_adc_counter()
            self.enable_daq()

    # execute scurve scan
    def scurve_scan(self, sx_scan_list: list = []):
        if sx_scan_list == []:
            sx_scan_list = self.smx_list
        log.info("pscan for %d ASICs", len(sx_scan_list))
        for n, sx in enumerate(sx_scan_list):
            sx.conf_func("vref_t", 56)
            sx.conf_func("daq_en", 0)
            log.info("\n ------ %d ----- I_CSA %d   %d -----\n", n, sx.read(130, 0), sx.read_vddm())
            sx.conf_func("csa_front", 23)
            sx.conf_func("csa_back", 23)
            sx.reset_adc_counter()
            sx.check_trim_red_fast(vp_min=40, vp_max=140)
            log.info("%x %x", sx.read(130, 10), sx.read(130, 18))
            log.info("%s %d %d", sx.trimfile, sx.vref_n, sx.vref_p)

    # save readback config
    #   currently: to file
    def save_config_hl(self):
        if self.dump_level > 0:
            self.save_config(save_level=self.dump_level)

    # --------------------------------------------------------------------------------------------------------------
    # --------------------------------------------------------------------------------------------------------------
    # --------------------------------------------------------------------------------------------------------------
    # --------------------------------------------------------------------------------------------------------------
    # --------------------------------------------------------------------------------------------------------------

    def eval_smx_list(self, smx_list: list) -> list:
        if not smx_list:
            return self.smx_list
        elif isinstance(smx_list[0], int):    # smx_list is list of integer asic IDs
            smx_list_o = []
            for smx in self.smx_list:
                if smx.a_id in smx_list:
                    smx_list_o.append(smx)
            return smx_list_o
        elif isinstance(smx_list[0], SmxD):   # smx_list is list of smx objects!!!
            return smx_list
        else:
            log.warning("Wrong type in smx list: %s, use full smx list instead", type(smx_list[0]))
            return self.smx_list

    def show_smx_list(self, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        # Overview of all smx i list  -----------------------------------------
        log.info("No \t ", "fuse".rjust(18), " \t id \t\t type \t modu \t aseq \t rob \t feb ")
        for i, smx in enumerate(smx_list):
            log.info("%d \t %s \t %s \t\t %s \t %d \t %d \t %d \t %d",
                     i, hex(smx.fuse_id).rjust(18), hex(smx.a_id), smx.type, smx.module, smx.aseq, smx.rob, smx.feb)
        log.info("number of smx: %d", len(self.smx_list))

    # print all function values  -------------------------------------------

    def show_func_vals(self, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        for smx in smx_list:
            for attr in dir(self.smconf):
                pp = getattr(smx, attr)
                log.info("%s   %d", attr, pp)

    # print sing function values  -------------------------------------------
    def show_func(self, f_list, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        if type(f_list) == str:
            f_list = [f_list]
        o_str = ""
        for f_str in f_list:
            o_str = o_str + f_str + "\t"
        log.info("%s", o_str)

        for smx in smx_list:
            o_str = str(smx.rob)+"  "+str(smx.feb)+"  "+str(smx.hw_addr)+"\t"
            for f_str in f_list:
                val = getattr(smx, f_str)
                o_str = o_str + str(val) + "\t"
            log.info("%s", o_str)

    def show_reg(self, r_list: list, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        o_str = ""
        for r in r_list:
            o_str = o_str + str(r[0])+","+str(r[1]) + "\t"
        log.info("%s", o_str)

        for smx in smx_list:
            o_str = "show_reg  " + str(smx.rob) + "  " + str(smx.feb) + "  " + str(smx.hw_addr) + "        " + \
                str(crf2seq[(smx.cri, smx.rob, smx.feb)][0]).rjust(4) + " " + str(crf2seq[(smx.cri, smx.rob, smx.feb)][1]).rjust(4) + "\t"
            for r in r_list:
                val = smx.read(r[0], r[1]) & 0xff
                o_str = o_str + hex(val) + "\t"
            log.info("%s", o_str)

    #  print overview of all ASIC parameters listed in cfg_l  -----------------------
    def show_cfg_l(self, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        cfg = collections.OrderedDict()
        for item in cfg_l:
            for f, d in default.items():
                if f[2:] == item[2:]:
                    cfg[item] = d

        log.info("\n\n")
        log_str = "ID\t"
        for f, d in cfg.items():
            # f = getattr(smx,f[2:])
            log_str = log_str + f[2:8] + "\t"
        log.info("%s", log_str)

        if self.test_mode:
            self.smx_list[0].af_thr = 3   # modify one parameter to test diff check
            self.smx_list[0].vref_t = 51   # modify one parameter to test diff check
        for smx in smx_list:
            log_str = hex(smx.a_id) + "\t"
            for f, d in cfg.items():
                if hasattr(smx, f[2:]):
                    val = hex(getattr(smx, f[2:]))
                    if val != hex(d):
                        val = '\033[91m' + val + "*" + '\033[0m'
                        # val = val + "*"
                else:
                    val = "   "
                log_str = log_str + val + "\t"
            log.info("%s", log_str)

        log_str = "ID\t"
        for f, d in cfg.items():
            # f = getattr(smx,f[2:])
            log_str = log_str + f[2:8] + "\t"
        log.info("%s", log_str)
        log.info("\n\n")

    # comparison of all ASIC parameters listed in cfg_l  -----------------------
    def diff_cfg_l(self, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        cfg = collections.OrderedDict()
        for item in cfg_l:
            for f, d in default.items():
                if f[2:] == item[2:]:
                    cfg[item] = d

        log_str = "ASIC ID\t"
        for f, d in cfg.items():
            # f = getattr(smx,f[2:])
            log_str = log_str + f[2:8] + "\t"
        log.info("%s", log_str)

        for smx in smx_list:
            log_str = hex(smx.a_id) + "\t"
            for f, d in cfg.items():
                if hasattr(smx, f[2:]):
                    val_act = smx.get_func_from_reg(f[2:], smc.R_ACT)
                    val_rbk = smx.get_func_from_reg(f[2:], smc.R_RBK)
                    if val_act != val_rbk:
                        val = '\033[91m' + str(val_act) + "*" + str(val_rbk) + '\033[0m'
                        # val = val + "*"
                    else:
                        val = str(val_act)
                else:
                    val = "   "
                log_str = log_str + val + "\t"
            log.info("%s", log_str)

    def show_glb_regs(self, rtype: int, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        # print register sets (130, 192) of SMX ASICs  ---------------------------------------------
        row = 130
        r130_cols = list(range(19)) + [20, 21, 22]
        log_str = "R.130\t"
        for col in r130_cols:            # range(23):
            log_str = log_str + str(col) + "\t"
        log.info("%s", log_str)
        for smx in smx_list:
            log_str = hex(smx.a_id) + "\t"
            for col in r130_cols:   # range(23):
                log_str = log_str + hex(smx.get_reg(rtype, row, col)) + "\t"
            log.info("%s", log_str)

        row = 192
        r192_cols = list(range(1, 15)) + list(range(18, 33)) + [34, 35, 36]
        log_str = "R.192\t"
        for col in r192_cols:    # range(37):
            log_str = log_str + str(col) + "\t"
        log.info("%s", log_str)
        for smx in smx_list:
            log_str = hex(smx.a_id) + "\t"
            for col in r192_cols:   # range(37):
                if col == 1:
                    # TODO: to avoid this, use proper bit mask in  each reg. note: 192,n regs. have almost all individual masks
                    log_str = log_str + hex(smx.read(row, col) & 0x3fff) + "\t"
                else:
                    log_str = log_str + hex(smx.get_reg(rtype, row, col)) + "\t"
            log.info("%s", log_str)

    def save_config(self, smx_list: list = None, save_level: int = 1):
        '''
        Read configuration data from all active ASICs and write to file (currently)
        args:  smx_list: list of asics to work on
               save level: defines which configuration content to save
                           1 - global registers (from row 130 and 192)
                           2 - channel configuration registers (ch 0,..127, row 63,65,67)
                           4 - hash of trim values (reads all trim regsters, aves singl hash value)
                           8 - all trim registers; includes the hash value
        '''
        smx_list = self.eval_smx_list(smx_list)

        if save_level & 0x1:
            r130_cols = list(range(19)) + [20, 21, 22]
            r192_cols = list(range(2, 15))   # + list(range(18,33)) + [34,35,36]

            # log_str = "R.130\t"
            log_str = "{ \nrnum: ["
            for col in r130_cols:            # range(23):
                log_str = log_str + str(col).rjust(2) + ", "
            # log_str = log_str + "R.192"
            log_str = log_str + "  "
            for col in r192_cols:    # range(37):
                log_str = log_str + str(col).rjust(4) + ", "
            log_str = log_str[:-2] + " ],\n"

            cfile_path = "conf_rb/"
            datestr = datetime.now().strftime("%y%m%d_%H%M%S")
            cfile_name = cfile_path + "conf_rb_" + datestr + ".txt"

            log.info("Write config to file %s", cfile_name)

            with open(cfile_name, 'w') as cf:
                cf.write(log_str)

                for smx in smx_list:
                    log.info(f"readback config for smx {hex(smx.a_id)}")
                    log_str = hex(smx.a_id) + ": ["
                    if save_level & 0x1:
                        for col in r130_cols:   # range(23):
                            log_str = log_str + "{0:0{1}x}".format(smx.read(130, col) & 0xff, 2) + ", "
                        log_str = log_str + "  "
                        for col in r192_cols:   # range(37):
                            log_str = log_str + "{0:0{1}x}".format(smx.read(192, col) & 0x3fff, 4) + ", "
                        log_str = log_str[:-2] + " ], "
                    if save_level & 0x2:
                        trim_strs = smx.read_trim()
                        for line in trim_strs:
                            cf.write(line)
                    if save_level & 0x4:
                        trim_hash =  smx.get_trim_hash()
                        log_str = log_str + "[ " + str(trim_hash) + "]"
                        pass
                    log_str = log_str + ",\n"

                    cf.write(log_str)
                cf.write("}")
        if save_level & 0x2:
            pass

        if save_level & 0x4 or save_level & 0x8:
            pass
            # readback trims
            # create and save hash
        if save_level & 0x8:
            pass
            # write trims

    def show_reg_set(self, rtype: int, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        # print register set of SMX ASICs   ---------------------------
        log_str = "R.130\t"
        for col in range(23):
            log_str = log_str + str(col) + "\t"
        log.info("%s", log_str)

        row = 130
        for smx in smx_list:
            smx.read_reg_all(compFlag=False)
            log_str = hex(smx.a_id) + "\t"
            for col in range(23):
                log_str = log_str + hex(smx.get_reg(rtype, row, col)) + "\t"
            log.info("%s", log_str)

    def set_channel_masks(self, mask: str = "mask_channels", smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        if hasattr(e_spar, mask):
            mask_channels = getattr(e_spar, mask)
        else:
            log.warning(f" Channel mask {mask} does not exist. Use default <mask_channels>")
            mask_channels = getattr(e_spar, "mask_channels")

        for smx in smx_list:
            # ch_list = mask_channels[smx.mseq][smc.cno[smx.chrg]]
            ch_list = mask_channels[smx.mseq]
            smx.set_mask_from_channels(ch_list)

    def check_dl_status(self, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        log.info("Check DL status on %d asics", len(smx_list) )
        n_test = 10       # 200
        thr_fail = 3      # 1
        ratio_fail = 0.7  # 0.0
        TESTED = 0
        FAILED = 1
        dl_check = [[[0 for f in [TESTED, FAILED]] for dl in range(5)] for cr in range(5)]
        for smx in smx_list:
            dl_check[smx.rob][smx.feb][TESTED] += 1
            n_fail = 0
            for i in range(n_test):
                val = smx.read(192, 1)
                if val == -1:
                    n_fail += 1
            if n_fail >= thr_fail:
                dl_check[smx.rob][smx.feb][FAILED] += 1
        result = []
        for cr in range(5):
            for dl in range(5):
                if dl_check[cr][dl][TESTED] > 0:
                    if float(dl_check[cr][dl][FAILED] / dl_check[cr][dl][TESTED]) > ratio_fail:
                        log.warning("Downlink Check FAILED: crob %d  FEB %d ", cr, dl)
                        result.append([cr, dl])
        return result

    def read_status(self, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        log.info("---- SMX Status ------------------------------------")
        smx_list[0].read_status(True)
        for smx in smx_list[1:]:
            smx.read_status()

    def read_setup(self, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        log.info("---- SMX Setup ------------------------------------")
        smx_list[0].read_setup(True)
        for smx in smx_list[1:]:
            smx.read_setup()

    def reg_diff(self, rtype1: int, rtype2: int, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        log.info("---- Register Differences %d %d ------------------------------------", rtype1, rtype2)
        for smx in smx_list:
            smx.reg_diff(rtype1, rtype2)

    def reg_to_func(self, rtype: int, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        for smx in smx_list:
            smx.set_reg_to_func(rtype)

    def read_reg(self, smx_list: list = None, compFlag: bool = False):
        smx_list = self.eval_smx_list(smx_list)
        for smx in smx_list:
            smx.read_reg_all(compFlag)

    def read_reg_to_func(self, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        for smx in smx_list:
            smx.read_reg_all(compFlag=True)
            smx.set_reg_to_func(smc.R_RBK)

    def conf_s_par(self, s_par: str, val: int = -1, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        for smx in smx_list:
            smx.conf_func(s_par, val)

    def set_trim(self, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        log.info("set_trim")
        for smx in smx_list:
            smx.set_trim()

    def set_trim_default(self, trim_val: int = 128, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        for smx in smx_list:
            smx.set_trim_default(trim_val)

    def write_and_readback_reg(self, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        for smx in smfux_list:
            smx.write_reg_all()
            smx.read_reg_all(compFlag=False)

    def write_reg_all(self, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        for smx in smx_list:
            log.info("func to reg asic %d %s %d", smx.mseq, smx.chrg, smx.aseq)
            smx.write_reg_all()

    def func_to_reg(self, rtype, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        for smx in smx_list:
            smx.func_to_reg(rtype)

    def read_efuse(self, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        efuse_vals = {}
        for smx in smx_list:
            val = smx.read_efuse()
            efuse_vals[smx.aseq] = val
        return efuse_vals
            
    def reset_alert_and_status(self, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        for smx in smx_list:
            smx.reset_alert_vals()
            smx.write(192, 27, 0)

    def read_vddm_formatted(self, offset: int = 0, vddm_range: int = 2000, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        vddm_map = [[9999 for a in range(16)] for module in range(len(topo)+1)]   # max module from any "module" list, e.g. "topo"
        for smx in smx_list:
            vddm = round(smx.read_vddm()-offset)
            try:
                vddm_map[smx.mseq][8*(1-smx.chrg_type)+smx.aseq] = vddm
            except IndexError:
                log.error(f"vddm mp: index {smx.mseq} {smx.a_id&0xf} does not exist!")
        log.info(f"      Vddm Map with OFFSET {offset}")
        for m in range(1, len(topo)+1):
            log_str = str(m) + "\t"
            for a in range(16):
                if abs(vddm_map[m][a]) < vddm_range:
                    log_str = log_str + str(vddm_map[m][a]).rjust(6)
                elif abs(vddm_map[m][a]) < 9999:
                    log_str = log_str + '\033[91m' + str(vddm_map[m][a]).rjust(6) +  '\033[0m'
                else:
                    log_str = log_str + "---".rjust(6)
            log.info(f"{log_str}")

    def adjust_icsa_for_vddm_ldo(self, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        for smx in smx_list:
            smx.adjust_icsa_for_vddm_ldo()

    def set_config_flags(self, flags=None, smx_list=None):
        smx_list = self.eval_smx_list(smx_list)
        for smx in smx_list:
            smx.set_config_flags(flags)

    def enable_daq(self, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        for smx in smx_list:
            smx.daq_enable()

    def disable_daq(self, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        for smx in smx_list:
            smx.daq_disable()

    def set_test_mode_fix(self, rate: int, divider: int = 1, rand: int = 0, duration: int = 0, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        for smx in smx_list:
            smx.set_test_mode_fix(rate, divider, rand, duration)

    def reset_test_mode(self, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        for smx in smx_list:
            smx.reset_test_mode()

    def gen_test_pulses(self, n_pulse: int = 100, amp_pulse: int = 180, grp: int = 0, smx_list: list = None, flags: int = 0):
        smx_list = self.eval_smx_list(smx_list)
        for smx in smx_list:
            smx.set_config_flags(flags)

    def mask_enable_all(self, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        for smx in smx_list:
            smx.set_channel_mask_enable_all()

    def mask_disable_all(self, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        for smx in smx_list:
            smx.set_channel_mask_disable_all()

    def read_ts(self, smx_list: list = None):
        smx_list = self.eval_smx_list(smx_list)
        ts_list = []
        for smx in smx_list:
            ts_list.append(smx.read(192, 1) & 0x3fff)
        log_str = "TS  "
        for n, ts in enumerate(ts_list):
            log_str = log_str + hex(ts).rjust(8)
            if n % 8 == 7:
                log.info(f"{log_str}")
                log_str = "TS  "

    def get_topo_asic(self, cri: int, rob: int, feb: int, asic: int):
        for sx in self.smx_list:
            if sx.cri == cri and sx.rob == rob and sx.feb == feb and sx.aseq == asic:
                return sx
        return None

    def get_mod_asic(self, mod: int, q: int, asic: int):
        if type(q) == int:
            if q == 0:
                q = "p"
            else:
                q = "n"
        for sx in self.smx_list:
            if sx.mseq == mod and sx.chrg == q and sx.aseq == asic:
                return sx
        return None

    def get_geom_asic(self, station: int, ladder: int, module: int, feb: int, asic: int):
        for sx in self.smx_list:
            if sx.station == station and sx.ladder == ladder and sx.module == module and sx.feb == feb and sx.aseq == asic:
                return sx
        return None

    def dump_defaults(self):
        # dump defaults to json file
        with open(self.p_path+'par_default.json', 'w') as fp:
            json.dump(default, fp)

    def dump_smx_json(self, file_name: str = "asics.json"):
        log.info("DUMP JSON")
        with open(self.p_path+file_name, "w") as pf:
            sd_list = []
            for n, smx in enumerate(self.smx_list):
                sd = smx.__dict__
                sd.pop('smconf')
                sd_list.append(sd)
            jl = json.dumps(sd_list, indent=2)
            pf.write(jl)

    def dump_smx_readback_json(self, file_name: str = "asics_rb", ts_flag: bool = True, compFlag: bool = True):
        log.info("DUMP READBCK TO JSON")
        if ts_flag:
            now = datetime.now()
            ts_str = now.strftime("_%y%m%d_%H%M%S")
        else:
            ts_str = ""
        with open(self.p_path+file_name + ts_str + ".json", "w") as pf:
            sd_list = []
            for n, smx in enumerate(self.smx_list):
                smx.read_reg_all(compFlag)
                sd = smx.regs[1:2]
                sd_list.append(sd)
            jl = json.dumps(sd_list, indent=2)
            pf.write(jl)

    def dump_smx_pickle(self, file_name: str = "asics", ts_flag: bool = False):
        log.info("DUMP PICKLE")
        if ts_flag:
            now = datetime.now()
            ts_str = now.strftime("_%y%m%d_%H%M%S")
        else:
            ts_str = ""
        with open(self.p_path+file_name + ts_str + ".pickle", "wb") as pf:
            pickle.dump(self.smx_list, pf)

    def get_smx_list_pickle(self, filename: str = "") -> list:
        # TODO: get mixed smx list: devices from config, then settings from pickled asics;
        #       important to handle cases of changes in active
        if filename == "":
            filename = self.dumpfile_pickle
        log.info("Retrieve SMX data from pickle file %s", self.p_path+filename)
        with open(self.p_path+filename + ".pickle", "rb") as f:
            smx_list = pickle.load(f)
        for smx in smx_list:
            setattr(smx, "smconf", self.smconf)
        return smx_list

    def topo_to_geom(self, c: int, r: int, f: int):
        """
        converts from topology coordinates (cri, rob, feb) and geometry coordinates (module, p/n)
        """
        for mod_nr, mod in topo.items():
            for f_nr, feb in enumerate(mod):
                if feb[0] == c and feb[1] == r and feb[2] == f:
                    log.debug("topo_to_geom: map found: %d %d %d %d %d %d ", c, r, f, mod_nr, f_nr, feb[1])
                    return (mod_nr, f_nr)
        log.info(f"topo_to_geom: did not find match for (c,r,f) {c},{r},{f}  ")
        return (0, 0)

