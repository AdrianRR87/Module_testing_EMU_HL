
import sys
import numpy as np
import logging as log

sys.path.append("smx_systems/sts/config/")

import msts_defs as smc
from smx_conf import SmxConf
from smx_oper import SmxOper
from smx_cal import SmxCal
#from cri_smx.smx import SmxAsic, SmxFeb

import mcbm_msts_active_single_par as e_spar 
#import mstsOpMan_2 as mstsOpMan


class SmxAsic(SmxOper, SmxCal):
    def __init__(self, a_id: int, smx_conf: SmxConf, def_dict: dict):
        super().__init__()
        #super().__init__(_smxFeb, asic_dict)
        # super(SmxAsic, self).__init__(_smxFeb, asic_dict)
        # super(Smx, self).__init__()

        self.smc = smx_conf

        self.a_id    = a_id
        self.fuse_id = -1
        self.version = -1
        self.aseq = -1    
        self.mseq = -1    
        self.hw_addr = -1    # .chip_address from hctsp
        self.type = 'o'     # FEB a or b        # STS
        self.chrg = ''      # p or n

        # topo
                                                                   # ToDo: entry node or similar
        self.slr = -1                                              # ToDo: SLR will become obsolete?? Alt:  CRI number over full setup
        self.cri = -1                                              # CRI = GERI
        self.rob = -1  # .crob_idx, .crob_mask from hctsp          # ROB = EMU = Tester 
        self.feb = -1  # .dlink,   .downlink_mask from hctsp

        for f, d in def_dict.items():
            # remove d_ from "default" key for attribute name
            fa = f[2:]
            setattr(self, fa, d)
            # print( getattr(self,fa) )

        # self.trim = ''
        self.trimfile = ''
        self.trim_vref_t = -1
         
        asic_rows = [r for r in range(131)]
        asic_rows.append(192)
        self.regs = [[[0 for col in range(69)] for row in asic_rows]
                     for n in range(smc.NR_SET)]

        self.moni_list = []
        self.moni_level = 0


    def get_reg(self, rtype: int, row: int, col: int) -> int:
        """ Returns a SW register value from any of the register sets
        args: register set, row, col 
        returns: register value
        """
        assert rtype < smc.NR_SET
        if row == 192:
            row = 131
        try:
            return self.regs[rtype][row][col]
        except IndexError:
            log.error("regType: %d    Row: %d    Col: %d", rtype, row, col)
            exit()

    def set_reg(self, rtype: int, row: int, col: int, val: int):
        """ Sets a SW register value to any of the register sets
        args: register set, row, col, set value 
        returns: na
        """
        assert rtype < smc.NR_SET
        if row == 192:
            row = 131
        self.regs[rtype][row][col] = val

    def set_regFunc(self, rtype: int, row: int, col: int, lsb: int, mask: int, val: int):
        """ Sets a Func value in a SW register in any of the register sets
        args: register set, row, col, func_lsb, func_mask(width), set value 
        returns: na
        """
        assert rtype < 2  # R_RBK(rtype=2) can only be set from HW register values
        if row == 192:
            row = 131
        val = val << lsb
        valm = val & mask
        clr_mask = ~mask & 0x3fff
        # print( hex(mask), hex(clr_mask))
        if val != valm:
            log.warning("Reg %d %d: wrong bitlength of value! %d", row, col, val)
        else:
            self.regs[rtype][row][col] = (
                self.regs[rtype][row][col] & clr_mask) | valm

    def write_f(self, func: str, val: int, rtype: int = smc.R_ACT):
        """ write Func value to ASIC HW and update register 
        write both to the smx ASIC and to the corresponding R_ACT register
        note: no func value is updated!
        args: Func name, set value, register type
        returns: na
        """
        # ToDo: this should only be possible for R_ACT !! check "Func" handling
        # log.info("write_f fund %s  value %d", func,val)
        try:
            f = getattr(self.smc, func)
        except AttributeError:
            log.error("Invalid Func Name: %s", func)
            exit()
        setattr(self, func, val)
        # set reg
        if self.get_reg(rtype, f.row, f.col) == -1:
            self.set_reg(rtype, f.row, f.col, 0)
        self.set_regFunc(rtype, f.row, f.col, f.lsb, f.mask, val)
        # write reg
        self.write(f.row, f.col, self.get_reg(rtype, f.row, f.col))
        log.info(f"write_f {func} Reg. {f.row}, {f.col}     val {self.get_reg(rtype, f.row, f.col)} is {val}")

    def write_u(self, row: int, col: int, val: int):
        """ write and update register
        write both to the smx ASIC and to the corresponding R_ACT(!) register
        note: no func value is updated!
        args: register row and col, set value
        returns: na
        """
        # ToDo: difference write_u and write_f ?????
        self.write(row, col, val)
        self.set_reg(smc.R_ACT, row, col, val)

    def write_reg_all(self):
        """ write all R_ACT register values to the ASIC HW
        args: na
        returns: na
        """
        for row in range(128):
            for col in [63, 65, 67]:
                self.write(row, col, self.get_reg(smc.R_ACT, row, col))
                if row == 1:
                    log.debug(f"WRA  {row},{col} : {self.get_reg(smc.R_ACT, row, col)}")
        row = 130
        #for col in range(23):
        #    self.write(row, col, self.get_reg(smc.R_ACT, row, col))
        #    log.debug(f"WRA {row},{col} : {self.get_reg(smc.R_ACT, row, col)}")
        row = 192
        col_list = [col for col in range(37)]
        col_list.remove(25)     # remove the uplink mask reg.
        for col in col_list:
            self.write(row, col, self.get_reg(smc.R_ACT, row, col))


    def write_def_ana_reg(self, asic_id: int, pol: int):
        """ write all R_ACT register values to the ASIC HW
            args: na
            returns: na
        """                                                                                           
        csa_in = 31
        pol = pol
        row = 130
        if (pol == 0):
            self.write(130, 2, 131)
        elif (pol == 1):
            self.write(130, 2, 163)
        else:
            pass
        '''
        if polarity == 1:
             self.write(row,  2,163)
             if asic_id == 0:
                 self.write(row, 7, 33) # 7->thr2glb
                 #self.write(row, 8, 27) # 8->vref_n
                 #self.write(row, 9, 59) # 9->vref_p
             if asic_id == 1:
                 self.write(row, 7, 34)
                 #self.write(row, 8, 28)
                 #self.write(row, 9, 58)
             if asic_id == 2:
                 self.write(row, 7, 33)
                 #self.write(row, 8, 27)
                 #self.write(row, 9, 59)
             if asic_id == 3:
                 self.write(row, 7, 33)
                 #self.write(row, 8, 27)
                 #self.write(row, 9, 59)
             if asic_id == 4:
                 self.write(row, 7, 33)
                 #self.write(row, 8, 27)
                 #self.write(row, 9, 59)
             if asic_id == 5:
                 self.write(row, 7, 33)
                 #self.write(row, 8, 27)
                 #self.write(row, 9, 59)
             if asic_id == 6:
                 self.write(row, 7, 33)
                 #self.write(row, 8, 27)
                 #self.write(row, 9, 59)
             if asic_id == 7:
                 self.write(row, 7, 33)
                 #self.write(row, 8, 27)
                 #self.write(row, 9, 59)
        else:
             self.write(row,  2,131)
             if asic_id == 0:
                 self.write(row, 7, 33)
                 #self.write(row, 8, 27)
                 #self.write(row, 9, 59)
             if asic_id == 1:
                 self.write(row, 7, 33)
                 #self.write(row, 8, 27)
                 #self.write(row, 9, 59)
             if asic_id == 2:
                 self.write(row, 7, 33)
                 #self.write(row, 8, 27)
                 #self.write(row, 9, 59)
             if asic_id == 3:
                 self.write(row, 7, 33)
                 #self.write(row, 8, 27)
                 #self.write(row, 9, 59)
             if asic_id == 4:
                 self.write(row, 7, 33)
                 #self.write(row, 8, 27)
                 #self.write(row, 9, 59)
             if asic_id == 5:
                 self.write(row, 7, 33)
                 #self.write(row, 8, 27)
                 #self.write(row, 9, 59)
             if asic_id == 6:
                 self.write(row, 7, 33)
                 #self.write(row, 8, 27)
                 #self.write(row, 9, 59)
             if asic_id == 7:
                 self.write(row, 7, 33)
                 #self.write(row, 8, 27)
                 #self.write(row, 9, 59)
        
        '''
        self.write(row,  0,  csa_in)
        self.write(row,  1,  20)
        self.write(row,  3,  31)
        self.write(row,  4,   0)
        self.write(row,  5,   0)
        self.write(row,  6,  31)
        self.write(row,  7,  40)
        self.write(row,  8,  22)
        self.write(row,  9,  58)
        self.write(row, 10, 128)
        self.write(row, 11,   0)
        self.write(row, 12,  30)
        self.write(row, 13,  csa_in)
        self.write(row, 14,  25)
        self.write(row, 15,  31)
        self.write(row, 16,  88)
        self.write(row, 17,   0)
        self.write(row, 18, 118)

        log.info("ASIC E-fused ID: {}".format(self.read_efuse_str()))
        log.info("reading 130, 0: %3d", self.read(row,   0) & 0xff)
        log.info("reading 130, 1: %3d", self.read(row,   1) & 0xff)
        log.info("reading 130, 2: %3d", self.read(row,   2) & 0xff)
        log.info("reading 130, 3: %3d", self.read(row,   3) & 0xff)
        log.info("reading 130, 4: %3d", self.read(row,   4) & 0xff)
        log.info("reading 130, 5: %3d", self.read(row,   5) & 0xff)
        log.info("reading 130, 6: %3d", self.read(row,   6) & 0xff)
        log.info("reading 130, 7: %3d", self.read(row,   7) & 0xff)
        log.info("reading 130, 8: %3d", self.read(row,   8) & 0xff)
        log.info("reading 130, 9: %3d", self.read(row,   9) & 0xff)
        log.info("reading 130, 10: %3d", self.read(row, 10) & 0xff)
        log.info("reading 130, 11: %3d", self.read(row, 11) & 0xff)
        log.info("reading 130, 12: %3d", self.read(row, 12) & 0xff)
        log.info("reading 130, 13: %3d", self.read(row, 13) & 0xff)
        log.info("reading 130, 14: %3d", self.read(row, 14) & 0xff)
        log.info("reading 130, 15: %3d", self.read(row, 15) & 0xff)
        log.info("reading 130, 16: %3d", self.read(row, 16) & 0xff)
        log.info("reading 130, 17: %3d", self.read(row, 17) & 0xff)
        log.info("reading 130, 18: %3d", self.read(row, 18) & 0xff)
        


    def read_reg_all(self, compFlag: bool = True):
        """ read back of all ASIC HW registers to R_RBK register set
        read all registers except for trim registers
        args: comparison flag; if set, compares the read back R_RBK values 
                                to the corresponding R_ACT values
                                writes log.warning for each mismatch 
        returns: na
        """
        for row in range(128):
            for col in [63, 65, 67]:   # range(68)
                self.set_reg(smc.R_RBK, row, col, self.read(row, col) & 0xff )
        row = 130
        for col in range(23):
            self.set_reg(smc.R_RBK, row, col, self.read(row, col) & 0xff)
        row = 192
        for col in range(37):
            self.set_reg(smc.R_RBK, row, col, self.read(row, col) & 0x3fff)    # TODO: proper individual masks

        if compFlag:
            for row in range(128):
                for col in [63, 65, 67]:
                    if self.get_reg(smc.R_RBK, row, col) != self.get_reg(smc.R_ACT, row, col):
                        log.warning("RB Error: %d %d \t readback: %d    active: %d", row, col, self.get_reg(
                            smc.R_RBK, row, col), self.get_reg(smc.R_ACT, row, col))
            row = 130
            for col in range(23):
                if self.get_reg(smc.R_RBK, row, col) != self.get_reg(smc.R_ACT, row, col):
                    log.warning("RB Error: %d %d \t readback: %d    active: %d", row, col, self.get_reg(
                        smc.R_RBK, row, col), self.get_reg(smc.R_ACT, row, col))
            row = 192
            for col in range(37):
                if self.get_reg(smc.R_RBK, row, col) != self.get_reg(smc.R_ACT, row, col):
                    log.warning("RB Error: %d %d \t readback: %d    active: %d", row, col, self.get_reg(
                        smc.R_RBK, row, col), self.get_reg(smc.R_ACT, row, col))


    def get_func(self, f_str: str):
        """ Get ASIC value of Func  
        args: func string
        returns: value (conf)
                 row and col for func    
        """
        # ToDo: check 
        conf = getattr(self, f_str)
        return conf, getattr(self.smc, f_str).row, getattr(self.smc, f_str).col

    def reg_copy(self, src: int, dest: int):
        """ Copy all registers between register sets
           note: regs index 131 contains asic row 192
        args: source and destination sets (int or smc.R_NN
        returns: na
        """
        for row in range(132):
            for col in range(69):
                self.regs[dest][row][col] = self.regs[src][row][col]

    # TODO

    # fill registers from functions  ---------------------------------------------
    def func_to_reg(self, rtype: int):
        """ copy all Func values to register set 
          copies all func values from config (self.smc) to the
          register set "rtype"
          note: does NOT write values to ASIC HW!
        args: register type
        returns: na
        """
        for attr in self.smc.__dict__.keys():
            f = getattr(self.smc, attr)
            val = getattr(self, attr)
            if f.row == 0:
                rows = list(range(128))
            else:
                rows = [f.row]
            for row in rows:
                if self.get_reg(rtype, row, f.col) == -1:
                    self.set_reg(rtype, row, f.col, 0)
                self.set_regFunc(rtype, row, f.col, f.lsb, f.mask, val)

    # set single config param (example: vref_t) from single_par.py  ------------------------------------
    def get_asic_par(self, s_par: str) -> int:
        """ get parameter value for given ASIC from "single_par" file
        args: parameter (func) name
        returns: parameter value for given ASIC
        """
        # ToDo: check if polarity is handled properly
        par = getattr(e_spar, "s_"+s_par)
        if not isinstance(par, dict):
            log.error("Par is no list: %s  %s", type(par), par)
            exit()
        seq = self.mseq
        pol = self.chrg
        ind = self.aseq
        mod = par[seq]
        log.info(f"SetVal: {pol}  {ind}")
        log.info(f"SetVal2: {smc.cno[pol]}")
        log.info(f"SetVal3: {mod}")
       
        setval = mod[1-smc.cno[pol]][ind]
        return setval

    def conf_func(self, s_par: str, val: int = -1):
        """ Write Func value to Reg and ASIC HW  
         uses write_t
         sets Func either to provided value or preset value
        args: Func name
              value ( optional ) 
        returns: na
        """
        if val == -1:
            setval = self.get_asic_par(s_par)
        else:
            setval = val
        self.write_f(s_par, setval, smc.R_ACT)

    def comp_reg_to_func(self, rtype: int):
        """ Compare Func values to register set 
            compare and print values or differences
        args: rtype register set
        returns: na
        """
        par_grps = [0, 130, 192]
        for pg in par_grps:
            log.info("--- ", pg, " ---------------------------------------------------------------------")
            for attr in self.smc.__dict__.keys():
                f = getattr(self.smc, attr)
                conf = getattr(self, attr)
                if f.row == pg:
                    reg_val = self.get_reg(rtype, f.row, f.col)
                    val = (reg_val & f.mask) >> f.lsb
                    # print f.row, f.col, "\t\t", val, "\t", hex(val)
                    if val == conf:
                        log.info("%s \t\t %d \t %d", attr.ljust(15), val, conf)
                    else:
                        log.warning("%s \t\t %d \t %d  -- DIFF!",
                                 attr.ljust(15), val, conf)

    def set_reg_to_func(self, rtype: int):
        """ Set Func values from register set
        args: source register set
        returns: na
        """
        par_grps = [0, 130, 192]
        for pg in par_grps:
            log.debug(
                "--- %d ---------------------------------------------------------------------", pg)
            for attr in self.smc.__dict__.keys():
                f = getattr(self.smc, attr)
                if f.row == pg:
                    reg_val = self.get_reg(rtype, f.row, f.col)
                    f_val = (reg_val & f.mask) >> f.lsb
                    setattr(self, attr, f_val)
                    log.debug("set func %s from reg %d %d %d to val %s",
                              attr, f.row, f.col, reg_val, f_val)

    def get_func_from_reg(self, func: str, rtype: int) -> int:
        """ Get value of a specific Func from register set 
        args: Func name
              register set  
        returns: func value
        """
        f = getattr(self.smc, func)
        reg_val = self.get_reg(rtype, f.row, f.col)
        func_val = (reg_val & f.mask) >> f.lsb
        return func_val

    def reg_diff(self, rtype1: int, rtype2: int):
        """ Compare register values of two sets 
          prints register values and eventually discrepancies 
        args: register set 1 and 2 for comaprison
        returns: na
        """
        par_grps = [0, 130, 192]
        reg_grps = [[63, 65, 67], list(range(23)), list(range(38))]
        for i, pg in enumerate(par_grps):
            log.info("--- ", pg, " ---------------------------------------------------------------------")
            for col in reg_grps[i]:
                val1 = self.get_reg(rtype1, par_grps[i], col)
                val2 = self.get_reg(rtype2, par_grps[i], col)
                if val1 == val2:
                    log.info("col %d\t\t  %d \t %d", col, val1, val2)
                else:
                    log.info("col %d\t\t  %d \t %d  - DIFF!", col, val1, val2)






    def add_monitoring(self, row: int, col: int):
        """ add a register to the monitoring functionality
        args: register row, col
        returns: na
        """
        self.moni_list.append([row, col])

    def clear_monitoring(self):
        """ clear monitoring list 
        args: na
        returns: na
        """
        self.moni_list = []
        self.moni_level = 0

    def set_moni_level(self, level: int):
        """ Set level for the monitoring functionality
        args: level  ( 0: off; >0: on )
        returns: na
        """
        self.moni_level = level

    def show_monitoring(self):
        """ Show status of a list of registers 
        args: na
        returns: na
        """
        if self.moni_level > 0:
            for m_reg in self.moni_list:
                row = m_reg[0]
                col = m_reg[1]
                o_str = "!!!!!  Moni (" + str(row).rjust(3) + ", " \
                        + str(col).rjust(2) + "): \t" + str(self.get_reg(smc.R_ACT, row, col)).rjust(3) \
                        + "\t" + str(self.get_reg(smc.R_RBK, row, col)).rjust(3) + "\t" \
                        + str(self.read(row, col)).rjust(3) + "  !!!!!!!!!!!!!!!!!!!!!!!"
                log.info("%s", o_str)


# 3456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
#        1         2         3         4         5         6         7         8         9        10        11        12

# TODO: update of registers whenever functions are changed; for this: make all setters ??!?!?
# TODO: channel mask functionality
