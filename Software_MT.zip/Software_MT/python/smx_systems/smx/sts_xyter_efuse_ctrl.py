import time
import logging as log
import numpy as np
from crccheck.crc import Crc3Rohc as Crc3
from crccheck.crc import Crc4Itu as Crc4
#from crccheck.crc import Crc3, CrcXmodem
from crccheck.checksum import Checksum32

MODE_FRAME = 0

CRC_POS = 0
CRC_MSK = 0xf
YPOS_POS = 4
YPOS_MSK = 0xff
XPOS_POS = 12
XPOS_MSK = 0xff
WAFER_POS = 20
WAFER_MSK = 0xff
BATCH_POS = 28
BATCH_MSK = 0xff
SER_POS = 36
SER_MSK = 0xf
TAG_POS = 48
TAG_MSK = 0xffff
ARB_POS = 40
ARB_MSK = 0xff


class qa_xyter_id(object):
  
    def __init__(self, id64 ):
        self.id64 = id64
        self.tag = 'na'    
        self.arb = 0
        self.series = 3
        self.batch = 0
        self.wafer = 0
        self.xpos = 0
        self.ypos = 0
        self.crc = 0
        self.is_ok_crc  = -1
        self.is_regular = -1
        self.is_unique  = -1
        self.is_in_db   = -1
                     
    
    def dump_id(self):
        print( "id64", hex(self.id64))
        #print "tag", hex(self.tag)
        #print "arb", hex(self.arb)
        #print "series", self.series
        #print "batch", self.batch
        #if self.series == 1:
        #    print "wafer", self.wafer
        #    print "xpos", self.xpos
        #    print "ypos", self.ypos
        #if self.series == 0:
        #    print "serial", (self.wafer<<16)+(self.xpos<<8)+self.ypos, "    ",hex((self.wafer<<16)+(self.xpos<<8)+self.ypos)
        #print "crc", self.crc
        #print "crc_ok", self.is_ok_crc



class sts_xyter_efuse_ctrl(object):
  
    def __init__(self, batch = 0, serial_offset = 0, serial_inc = 1):
        self.max_PreSeries_Serial = 2**24-1 # 8bit wafer, 8bit xpos, 8bit ypos
        serial_inc = serial_inc & 0x1ff      # max. increment 256
        self.PreSeries_Serial_Inc = serial_inc
        serial_offset = serial_offset & 0xffffff    
        self.PreSeries_Serial_Offset = serial_offset
        batch = batch & BATCH_MSK
        self.PreSeries_Batch = batch    #  6b  

    
    def is_valid(self, id, except_list = []):
        xyter_efuse_id = self.decode_id(id)    
        if (xyter_efuse_id.is_ok_crc == 1):
            return(1)
        elif ( id in set(except_list)): 
            return(2)
        else:
            return(0)


    #def exist_xyter_id(self, id):

    #  --- ASIC ID --- 
    #  63..48     tag ("XA")
    #  47..40     arb. code ( def: "0x00")
    #  39..36     series 
    #  35..28     batch
    #  27..20     wafer
    #  19..12     xpos
    #  11..04     ypos
    #  03..00     CRC   ( CRC4-ITU)


    def decode_id(self, id):

        #print "decode_id ",   type(id)
        id_dec = qa_xyter_id(id)
        crc = id & CRC_MSK
        crc_ok = self.isvalid_crc(id)
        if crc_ok == 0:
            id_dec.is_ok_crc = crc_ok 
            return(id_dec)
    
        tag = []
        tag.append((id >> (TAG_POS+8)) & 0xff)
        tag.append((id >>  TAG_POS   ) & 0xff)
        tag_str = chr(tag[0]) + chr(tag[1])
        id_dec.id64 = id                  
        id_dec.tag = tag_str
        id_dec.arb = (id>> ARB_POS) & ARB_MSK                   
        id_dec.series = (id>> SER_POS) & SER_MSK 
        id_dec.batch = (id>> BATCH_POS) & BATCH_MSK
        id_dec.wafer =  (id>> WAFER_POS) & WAFER_MSK 
        id_dec.xpos  =  (id>> XPOS_POS) & XPOS_MSK 
        id_dec.ypos  = (id>> YPOS_POS) & YPOS_MSK 
        id_dec.crc   = crc
        id_dec.is_ok_crc = crc_ok 
        return(id_dec)

  
    def get_id_str(self, idd):
        if (idd.tag == '\x00\x00'):
            id_str = "XX-"+str(idd.arb).zfill(3)+"-"+str(idd.series).zfill(2)+"-"+str(idd.batch).zfill(3)+"-"+str(idd.wafer).zfill(3)+"-"+str(idd.xpos).zfill(3)+"-"+str(idd.ypos).zfill(3)+"-"+str(idd.crc).zfill(2)
        else:
            id_str = idd.tag+"-"+str(idd.arb).zfill(3)+"-"+str(idd.series).zfill(2)+"-"+str(idd.batch).zfill(3)+"-"+str(idd.wafer).zfill(3)+"-"+str(idd.xpos).zfill(3)+"-"+str(idd.ypos).zfill(3)+"-"+str(idd.crc).zfill(2)        
        return id_str
  
      
    def isvalid_crc(self, id):
        #print "isvalid_crc ",   type(id)
        
        crc_calc = self.get_crc(id)
        crc_data = np.uint64(id) & np.uint64(0xf)
        #print crc_data, crc_calc
        if crc_data == crc_calc:
            return(1)
        else:
            return(0)


    def get_crc(self, id):
        #print "get_crc",   type(id)
        
        data1 = (id >>4  ) & 0xfffffffffffffff
        data = bytearray([ (data1 >> sh) & 0xff for sh in range(60, -4,-8)])
        crc = Crc4.calc(data)
        return(crc) 


  # def get_crc2(self, id):
  #   print hex(id)
  #   data1 = (id>>3) & 0x1fffffffffffffff
  #   data = bytearray.fromhex("0"+str(data1))
  #   crc = Crc3.calc(data)
  #   print crc
  #   for i in range(8):
  #     print hex(data[i])
  #   #checksum = Checksum32.calc(data)
  #   return(crc) 
  
  # def get_crc3(self, id):
  #   print hex(id), hex(id>>3)
  #   data1 = (np.uint64(id) >> np.uint64(3) ) & np.uint64(0x1fffffffffffffff)
  #   data = bytearray([ (np.uint64(data1) >> np.uint64(sh) ) & np.uint64(0xff) for sh in range(60, -4,-4)])
  #   crc = Crc3.calc(data)
  #   print crc
  #   #datat = bytearray.fromhex(str(0xDEADBEEF76543210DEADBEEF765432105324))
  #   for i in range(16):
  #     print hex(data[i]) #, hex(datat[i])
  #   #checksum = Checksum32.calc(data)
  #   return(crc) 


                     

