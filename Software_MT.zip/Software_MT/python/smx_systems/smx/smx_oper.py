import sys
import time
from datetime import datetime
import logging as log
import json
import glob
import random
import os
import re
import numpy as np

import msts_defs as smc
# import smx_efuse 
from sts_xyter_efuse_ctrl import  sts_xyter_efuse_ctrl

'''
class trim_set(object):

    def _init__(self, def_trim):
        self.trim = def_trim
        self.cnt = -1
        self.tdir = 99   # -1: down    1: up
        self.trim_max = 0
        self.trim_min = 255
        self.active = True
'''

class SmxOper(object):
    """class to provide higher level functionality to the smx class
       Implements methods for configuration and operation of a single smx

    """
    def __init__(self):
        super().__init__()

    def read_status(self, header: bool = False):
        """ Read status information:
        Asic ID, Efuse ID, HW address, SW seq address, link mask,
        AF, EM, SEU counters
        status register, cmd exe delay, temperature

        args: header - flag if header line with displayed fields is logged
                       ( in order to suppress header in case status of multiple ASICs is shown
        return: na ( TODO: return list with status fields)

        does: logs one line with all the status fields
        """

        status_txt = ["ID", "fuseID".rjust(18), "HwAddr", "Seq", "Type", "ChReg", "LnkMsk", "AFCnt",
                      "EMCnt", "SEUCnt", "Status", "ExeDly", "Temp", "Vddm"]
        o_str = ""
        for item in status_txt:
            o_str = o_str + item + "\t"
        if header:
            log.info("%s", o_str)

        # TODO: replace hardcoded registers by functions
        o_str = hex(self.a_id) + "\t"
        o_str = o_str + hex(self.read_efuse()).rjust(18)
        o_str = o_str + "\t" + str(self.read(192, 22) & 0xFFF)
        o_str = o_str + "\t" + str(self.aseq)
        o_str = o_str + "\t" + str(self.ftype)      # ToDo: check ftype
        o_str = o_str + "\t" + str(self.read(130, 2) & 0xff)    # & 0x20
        o_str = o_str + "\t" + str(self.read(192, 25) & 0x3FF)
        o_str = o_str + "\t" + str(self.read(192, 24) & 0xFFF)
        o_str = o_str + "\t" + str(self.read(192, 30) & 0xFFF)
        o_str = o_str + "\t" + str(self.read(192, 31) & 0xFFF)
        o_str = o_str + "\t" + str(self.read(192, 27) & 0xFFF)
        o_str = o_str + "\t" + str(self.read(192, 35) & 0xFFF)
        o_str = o_str + "\t" + str(int(self.read_temp()))
        o_str = o_str + "\t" + str(int(self.read_vddm()))
        log.info("%s", o_str)

    def read_setup(self, header: bool = False):
        """ Read setup information:
          efuse_id, aseq, ftype, crob_idx, dlink, rob, feb, mseq, aseq, trimfile

        args: header - flag if header line with displayed fields is logged
                       ( in order to suppress header in case status of multiple ASICs is shown
        return: na ( TODO: return list with status fields)

        does: logs one line with all the status fields
        """

        status_txt = ["ID", "fuseID".rjust(18), "HwAddr", "Seq", "Type", "ChReg", "cr_idx", "dl_feb",
                      "rob", "feb", "mseq", "aseq"]
        o_str = ""
        for item in status_txt:
            o_str = o_str + item + "\t"
        if header:
            log.info("%s", o_str)

        # TODO: replace hardcoded registers by functions
        o_str = hex(self.a_id) + "\t"
        o_str = o_str + hex(self.read_efuse()).rjust(18)
        o_str = o_str + "\t" + str(self.read(192, 22) & 0xFFF)
        o_str = o_str + "\t" + str(self.aseq)
        o_str = o_str + "\t" + str(self.ftype)
        o_str = o_str + "\t" + str(self.read(130, 2) & 0x20)
        o_str = o_str + "\t" + str(self.crob_idx)
        o_str = o_str + "\t" + str(int(self.dlink/2))
        o_str = o_str + "\t" + str(self.rob)
        o_str = o_str + "\t" + str(self.feb)
        o_str = o_str + "\t" + str(self.mseq)
        o_str = o_str + "\t" + str(self.aseq)
        o_str = o_str + "\t" + str(self.trimfile)

        log.info("%s", o_str)

    def read_config(self):
        """ Read and log ASIC configration

            Shows the following configuration register:
             channels: reg. 63, 65, 67  (no trims)
             analog:   reg. 130,0..22
             digital:  reg. 192,0..36
        """
        log.info("ASIC Nr. %d  Addr %d   uln %d ", self.chip_nr, self.chip_addr, self.phys_uln)

        for ch in range(130):
            log.info("Ch. %d  \t\treg. 63 \t0x%x\t\treg. 65 \t0x%x\t\treg. 67 \t0x%x", ch,
                     self.read(ch, 63) & 0xff, self.read(ch, 65) & 0xff, self.read(ch, 67) & 0xff)

        log_str = "Row 130 \t"
        for reg in range(23):
            log._str = log_str + str(reg) + " " + str(self.read(130, reg) & 0xff) + "\t"
        log.info("%s", log_str)

        for reg in range(37):  # [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]:
            log.info("Reg 192,%d   \t0x%x", reg, self.read(192, reg) & 0x3fff)



    def read_efuse(self) -> int:
        """ Read ASIC Efuse Value
        args: na
        returns: efuse value as integer
        """
        fuse_value_bits = []
        fuse_reg_val = 0
        # Set ENB = 0
        self.write(192, 32, 0)
        time.sleep(0.000001)

        for A in range(7, -1, -1):
            # Set A
            self.write(192, 32, A)
            time.sleep(0.000001)
            # Set READ = 1
            self.write(192, 32, 128+A)
            time.sleep(0.000001)
            # Set READ = 0
            self.write(192, 32, A)
            time.sleep(0.000001)
            read_byte = self.read(192, 33)
            # print 'Dout[' + str(A) + '] = ' + str(read_byte)
            log.debug("Dout = {}".format(read_byte))

            bits = [(read_byte >> bit) & 1 for bit in range(8 - 1, -1, -1)]
            for bit in bits:
                fuse_value_bits.append(bit)
                fuse_reg_val = (fuse_reg_val << 1) | bit

        # Set ENB = 1
        self.write(192, 32, 64)
        # return(fuse_value_bits)
        fuse_reg_val = fuse_reg_val & 0xffffffffffffffff

        if self.fuse_id == -1:
            self.fuse_id = fuse_reg_val
            # TODO: fuse_id should not be set from readback (self consistent!)
            #       but from setup to allow for cross check
        return(fuse_reg_val)

    def read_efuse_str(self) -> str:
        """ provides ASIC efuse value in official format as string
        args: na
        returns: decoded efuse ID string in format XA-000-00-001-064-003-048-11
        """
        fctl = sts_xyter_efuse_ctrl()

        fid = self.read_efuse()
        id_dec = fctl.decode_id(fid)
        id_str = fctl.get_id_str(id_dec)
        return id_str

    
    def set_channel_mask(self, val: int):
        """ Set all channel mask register to a fixed value
        args: 14bit mask REGISTER value (note: not full ASIC mask!)
        returns: na
        """
        assert 0 <= val <= 0x3fff
        mask = 0
        for i in range(10):
            mask = mask << 14 & val
        self.mask = mask
        for r_col in range(4, 14):
            self.write_u(192, r_col, val)     # 0 enables

    def set_channel_mask_enable_all(self):
        """ Enable all channels
        sets channel masks to 0
        args: na
        returns: na
        """
        self.set_channel_mask(0)

    def set_channel_mask_disable_all(self):
        """ Disable all channels
        sets channel masks to 0x3fff
        args: na
        returns: na
        """
        self.set_channel_mask(0x3fff)

    def set_channel_mask_enable_even(self):
        """ Enable only all even channels
        sets channel masks to 0x1555
        args: na
        returns: na
        """
        self.set_channel_mask(0x1555)

    def set_channel_mask_enable_odd(self):
        """ Enable only all odd channels
        sets channel masks to 0x2aaa
        args: na
        returns: na
        """
        self.set_channel_mask(0x2aaa)

    def reset_test_mode(self):
        """ Disables all test modes
        in regs (192, [18..20])
        args: na
        returns: na
        """
        for col in [18, 19, 20]:
            self.write_u(192, col, 0)

    def set_test_mode_fix(self, rate: int = 1, divider: int = 1, rand: int = 0, duration: int = 0):
        """ Enable test modes 1: hit frames at fixed rate
        args: rate ( required )
              rate divider (default 1)
              randomized bits ( default 0 )
              duration in sec ( default 0 --> no stop of pulses;
                                otherwise: disable after duration )
        returns: na
        """
        val = (rate & 0x1f) | (rand & 0x7) << 5 | (divider & 0x7) << 8
        self.write_u(192, 19, val)
        self.write_u(192, 18, 2)
        if duration > 0:
            time.sleep(duration)
            self.write_u(192, 18, 0)

    # TODO: other test modes as needed

    def read_temp(self) -> float:
        """ Read ASIC temperature from diagnostic circuit
        args: na
        returns: temperate in deg. C
        """
        v_thr, dac_thr = self.read_diag("Temp")
        #temp = -0.5412 * v_thr + 379.91      # Is this temp. calibration valid for all ASICs ??????? # Outdated
        temp = -0.471 * v_thr + 363.016      # A general one from LM
        temp = round(temp*10)/10
        return v_thr, temp

    def read_vddm(self) -> float:
        """ Read Vddm voltage from diagnostic circuit
        args: na
        returns: voltage in mV
        """
        v_thr, dac_thr = self.read_diag("Vddm")
        return dac_thr, v_thr

    # TODO read Aux

    def read_diag(self, src) -> float:
        """ Read value from diagnostics circuit
        args: src - mux value for source selection
        returns: measured value in mV
        """
        if isinstance(src, str):
            if src == "Temp":
                msrc = 3
            elif src == "Vddm":
                msrc = 7
            elif src == "Aux":
                msrc = 0
            elif src == "CsaBias":
                msrc = 5
            else:
                log.warning("read_diag: unknown source string %s. Use default TEMP. ", src)
                msrc = 3
        elif isinstance(src, int):
            pass
        else:
            log.warning("read_diag: wrong source type %s. Use default TEMP. ", type(src))
            msrc = 3
        self.write(130, 20, msrc)

        dac_thr = 0b10000000   # half range: starting point
        for i in range(0, 8):
            self.write(130, 22, dac_thr)
            time.sleep(0.01)
            result = self.read(192, 34)
            if result > 0:
                if i == 7:
                    pass
                else:
                    dac_thr = dac_thr | (2**(6-i))  # set next bit
            else:
                dac_thr = dac_thr & ~(2**(7-i))  # clear current
                if i == 7:
                    pass
                else:
                    dac_thr = dac_thr | (2**(6-i))  # set next bit
        # log.info(f"dac thr {dac_thr}")
        #v_thr = (dac_thr**2) * (-0.0026) + 6.8971 * dac_thr + 3.2474   outdated
        v_thr = (dac_thr**2) * (-0.00496) + 7.6683 * dac_thr - 0.4546   #Irakli
        return v_thr, dac_thr

    def reset_alert_vals(self):
        """ Deactivates the AF, EM functionality
        sets AF and EM thresholds to 255
        resets AF, EM (and SEU) counters
        args: na
        returns: na
        """
        self.write_u(192, 23, 255)
        self.write_u(192, 24, 0)
        self.write_u(192, 29, 255)
        self.write_u(192, 30, 0)
        self.write_u(192, 31, 0)

    def set_config_flags(self, flags=None):
        """ Set the config flags in register 192,3
        args: integer with flag_pattern
        returns: na  
        """
        if flags is None:
            flags = self.get_reg(smc.R_ACT, 192, 3) & 0xff
        else:
            self.set_reg(smc.R_ACT, 192, 3, flags)
        assert flags < 256
        self.write(192, 3, flags)

    def set_alert_thresholds(self, af_thr: int, em_thr: int):
        """ Sets alert thresholds for AF and EM
        args: AF threshold
              EM threshold
        returns: na
        """
        self.write(192, 23, af_thr)
        self.write(192, 29, em_thr)

    def reset_asic(self, bitmask: int = 0x6e):
        """ executes reset of var. functionality
            using all resets available in register (192, 2)
            sets and clears the reset bits
        args: bitmask - mask of resets to execute
                        note: the default bitmask does not reset the timestamp counter
        returns: na
        """
        bitmask = bitmask & 0x7e
        self.write(192, 2, bitmask)
        self.write(192, 2, 0)

    def reset_channel_fifos(self):
        """ Executes reset of channel fifos
        args: na
        returns: na
        """
        self.reset_asic(0x2)

    def reset_adc_counter(self):
        """ Executes reset of ADC counters
        args: na
        returns: na
        """
        self.reset_asic(0x20)

    def daq_enable(self):
        """ Enable the DAQ (global gate)
        just calls global_gate_enable
        args: na
        returns: na
        """
        self.global_gate_enable()

    def daq_disable(self):
        """ Disable the DAQ (global gate)
        just calls global_gate_disable
        args: na
        returns: na
        """
        self.global_gate_disable()

    def global_gate_enable(self):
        """ Enable Global Gate for acquisition
            note: function is now called "daq_en"
            TODO: consider renaming the method to "daq_enable"
        args: na
        returns: na
        """
        reg_val_prev = self.get_reg(smc.R_ACT, 130, 11) & 0xff
        reg_val_new = reg_val_prev & 0xbf
        log.debug("Ensable Global Gate (%d)", reg_val_new)
        self.write_u(130, 11, reg_val_new)

    def global_gate_disable(self):
        """ Disable Global Gate
            note: function is now called "daq_en"
            TODO: consider renaming the method to "daq_disable"
        args: na
        returns: na
        """
        reg_val_prev = self.get_reg(smc.R_ACT, 130, 11) & 0xff
        reg_val_new = reg_val_prev | 0x40
        log.debug("Disable Global Gate (%d)", reg_val_new)
        self.write_u(130, 11, reg_val_new)

    def set_elink_mask(self, mask):
        assert 0 <= mask < 32
        mask_val = mask | mask << 5
        log.info(f"set elink mask {mask_val}")
        self.write_u(192, 25, mask_val)

        
    def read_adc_counter(self, channels: list = [], disc: list = [], sprint: bool = True ) -> list:
        """ Reads and logs channel ADC counter
        args: channels: channel list ( default: [] --> mapped to all channels 0,..,127 )
              sprint: write counter array to log.info
        returns: 2d list of counter values (ch, disc)
        """
        ch_max = 128
        d_max = 31
        # Read and printout the ADC and fast ch counters
        if not channels:
            channels = range(0, ch_max, 1)
        if not disc:
            disc = range(0, d_max+1)      # +1 for fast disc.
        ch_max = 128


        read_val = [ [0 for d in range(0, d_max+1)] for ch in range(0, ch_max, 1) ]

        log_line = "ADC Id"
        for d in disc:
            log_line = log_line + '{:7d}'.format( d )
        log_line = log_line + "   fast"
        if sprint:
            log.info( log_line )
        for ch in channels:
            log_line = "ch " + '{:3d}'.format( ch )
            for d in disc[:-1]:
               #read_val[ ch ][ d ] = self.read(ch, 61 - 2 * d - 1 )
                read_val[ ch ][ d ] = self.read(ch, 2 * d )
                log_line = log_line + '{:7d}'.format( read_val[ ch ][ d ] )
            read_val[ ch ][ d_max ] = self.read( ch, 62 )
            log_line = log_line + '{:7d}'.format( read_val[ ch ][ d_max ] )
            if sprint:
                log.info( log_line )
        return read_val

    def gen_test_pulses(self, n_pulse: int = 100, amp_pulse: int = 180, grp: int = 0):
        """ Generates analog test pulses ( amp_cal )
        generates n pulses for selected channel groups
        args: n_pulse: number of pulses ( default: 100 )
              amp_pulse: pulse amplitude ( default: 180 )
              grp: list of channel groups or single group as integer (default: group 0)
                     TODO: change default to [0,1,2,3] - all groups
        returns: na
        """
        if isinstance(grp, int):
            grp = [ grp ]
        for g in grp:
            self.cal_grp = g
            self.amp_cal = amp_pulse
            v_130_5_orig = self.get_reg(smc.R_ACT, 130, 5)
            self.write(130, 5, self.cal_grp + (self.sh_slow_fs << 2) )
            self.write_u(130, 4, self.amp_cal)
            glob_gate_def = self.get_reg(smc.R_ACT, 130, 11) & 0xff

            #log.info("ASIC %d: write %d pulses with amplitude %d to group %d", self.a_id, n_pulse, amp_pulse, g)
            log.debug("prev. glob gate register value: %d", glob_gate_def)
            for i in range(n_pulse):
                self.write(130, 11, glob_gate_def | 0x80)
                #time.sleep(0.0003)
                self.write(130, 11, glob_gate_def )
                #time.sleep(0.0003)
            self.write_u(130, 5, v_130_5_orig)




    def set_trim(self, trim_dir: str = "", pol: int = 0, hw_addr: int = 0, asic_id: str =""):
        """ Set trim values from a trim data source
          source may be the a file name or 
                            a trim tag (not implemented yet)
            if n o file name is provided, the asic "trim_file" is used
            that was set during asic initialisation (this should be the default)
        args: trim data source (typically none provided)
        returns: na
        """
        ch_min = 0
        ch_max = 128;
        d_min = 0;
        d_max = 31;
        trim_ok_min = 0;
        trim_ok_max = 255;
        default_slow_trim = 128
        default_fast_trim =  36
        
        #example: ftrim_XA-000-08-002-000-001-216-11_HW_0_SET_3865_3897_3962_3865_R_30_240_elect.txt
        if (pol == 0):
            pattern = r'^ftrim_' + str(asic_id) + r'_HW_' + str(hw_addr) + r'_SET_\d{2}_\d{2}_\d{3}_\d{2}_R_\d{2}_\d{3}_elect\.txt$'
        if (pol == 1):
            pattern = r'^ftrim_' + str(asic_id) + r'_HW_' + str(hw_addr) + r'_SET_\d{2}_\d{2}_\d{3}_\d{2}_R_\d{2}_\d{3}_holes\.txt$'
            
        #if ( pol == 0 ):
        #    pattern = r'^ftrim_asic_addr_' + str(asic_id) + r'_\d{3}_\d{3}_\d{3}_\d{3}_vp_\d{3}_\d{3}_\d{3}_elect\.txt$'
        #if ( pol == 1 ):
        #    pattern = r'^ftrim_asic_addr_' + str(asic_id) + r'_\d{3}_\d{3}_\d{3}_\d{3}_vp_\d{3}_\d{3}_\d{3}_holes\.txt$'

        file_list = os.listdir(trim_dir)
        matching_files = [file for file in file_list if re.match(pattern, file)]
        if (len(matching_files) == 0):
            # Set default Trim values
            log.info("NO MATCHING TRIM FILE for ASIC with EFUSE ID {}. DEFAULT TRIM VALUES SET INSTEAD".format(asic_id))
            self.set_trim_default(default_slow_trim, default_fast_trim)
        else:
            filename_trim = trim_dir + matching_files[0]
            self.writing_trim(filename_trim)

    def writing_trim(self, filename_trim: str = ""):
        # open file and read the Vref p, Vref N and Thr2_glb values
        f = open(filename_trim, "r")
        line_cnt = 0

        ch_min = 0
        ch_max = 128;
        d_min = 0;
        d_max = 31;
        trim_ok_min = 0;
        trim_ok_max = 255;
        default_slow_trim = 128
        default_fast_trim =  36
        
        num = []
        for x in f:
            if (x[0] == '#' and line_cnt >2 and line_cnt<6 ):
                print(x)
                num = [int(s) for s in x.split() if s.isdigit()]
                if (line_cnt == 3):
                    self.write(130, 9, num[0])
                    log.info("Read VRef_P: {}".format(self.read(130,9)&0xff))
                elif (line_cnt == 4):
                    self.write(130, 8, num[0])
                    log.info("Read VRef_N: {}".format(self.read(130,8)&0xff))
                elif (line_cnt == 5):
                    self.write(130, 7, num[0])
                    log.info("Read Thr2_glb: {}".format(self.read(130,7)&0xff))
                else:
                    pass
            line_cnt +=1
        f.close()
        
        trim = [ [0 for d in range(d_min,d_max+1)] for ch in range(ch_min, ch_max)]

        data = np.genfromtxt( filename_trim )
        
        chn = data[:,1]
        disc_thr = data [:,][:,2:34]

        for ch in range (ch_min,ch_max):
            for d in range (d_min,d_max):
                trim[ch][d] = int(disc_thr[:,d][ch:ch+1])
                if (trim[ch][d] < 70):                                                                                    
                    trim[ch][d] = default_slow_trim
                if (trim[ch][d] > 200):
                    trim[ch][d] = default_slow_trim
            trim[ch][d_max] = int(disc_thr[:,d_max][ch:ch+1])
            if (trim[ch][d_max] < 0):
                trim[ch][d_max] = default_fast_trim
            if (trim[ch][d_max] > 56):                                                                                                      
                trim[ch][d_max] = default_fast_trim
              
        for ch in range(ch_min,ch_max):                                                                                                  
            log_line = "ch: " + '{:3d}'.format( ch )                                                      
            for d in range (d_min,d_max):
                set_val_trim = trim[ch][d]
                if (set_val_trim < 70):
                    set_val_trim = default_slow_trim
                if (set_val_trim > 200):
                    set_val_trim = default_slow_trim                                                        
                log_line = log_line + ' {:3d}'.format( set_val_trim )
                disc = 61- 2*d                                                                              
                self.write( ch, disc, set_val_trim)                                                         
            log_line = log_line + ' {:3d}'.format( trim[ch][31])                                           
            self.write( ch, 67, trim[ch][31])

        log.info( ">>------------ READING trim values ---------------<<" )
        log_line = ""
        for ch in range(ch_min,ch_max):
            log_line = ""
            log_line = log_line + "ch: " + '{:3d}'.format( ch )
            for d in range (d_min,d_max):
                disc = 61- 2*d                                            
                val_f = self.read( ch, disc) & 0xff  
                log_line = log_line + ' {:3d}'.format( val_f )            
            log_line = log_line + ' {:3d}'.format( self.read( ch, 67 ) & 0xff )   
            log_line = log_line
            log.info( log_line )

        
        '''    
        if filename_trim == "":
            filename_trim = self.trimfile
            log.info(f"Asic ({self.mseq} {self.chrg} {self.aseq}) configure with trim file   {filename_trim}")
        elif filename_trim == "XXXXXX_XXXX" or filename_trim == "":
            log.warning("No specific trim file set, instead XXXXXX_XXXX. Configure trim with default value ")
            self.set_trim_default()
            return
        else:       
            log.info(f"Configure with provided trim file {filename_trim}")
        '''
        '''
        # define range of "good" trim values
        slow_trim_ok_min = 35
        slow_trim_ok_max = 250
        default_slow_trim = 128 

        fast_trim_ok_min = 5
        fast_trim_ok_max = 60
        default_fast_trim = 36

        # settings.trim_offset[ sdpb_idx ][ crob_idx ][ feb_idx ][ sx_idx_real ]
        slow_trim_offset_even = self.get_asic_par("trim_offset_even")
        slow_trim_offset_odd = self.get_asic_par("trim_offset_odd")
        if slow_trim_offset_even != 0 or slow_trim_offset_odd != 0:
            log.warning("TRIM Offset for ASIC %d %s %d:  even %d  odd %d ", self.mseq, self.chrg, self.aseq,
                        slow_trim_offset_even, slow_trim_offset_odd  )

        # cross check ID from file and read from ASIC
        # id_str_dev = self.read_efuse_str()

        # xa_pos = filename_trim.find("XA")
        # id_str_file = filename_trim[xa_pos:xa_pos+28]
        # if id_str_dev != id_str_file:
        #    log.error("ID in filename %s does not match device ID %s!!!", id_str_file, id_str_dev)
        #    log.error(" Skip trim setting for this ASIC")
        #    return

        # tag_str = filename_trim[filename_trim.find("Tag_")+len("Tag_") :filename_trim.find(".")]
        # if tag_str != settings.trim_tag:
        #    log.error("tag in filename %s does not match settings tag %s!!!
        #                Skip trim setting for this ASIC", tag_str, settings.trim_tag)
        #    return
        # log.info("Configure ASIC %d ( ID %s ) with tag %s ( File %s )",
        #  self.chip_nr, id_str_dev, tag_str, filename_trim)

        # get trim data from file

        # print(filename_trim)
        fstr = filename_trim
        data = np.genfromtxt(filename_trim, comments="#")
        # print(data)
        # chn = data[:,1]

        # adjust values where necessary; separately for slow and fast trims
        # then merge slow and fast again to single np array
        slow_disc_thr = data[:, ][:, 2:33]
        slow_disc_thr[0::2, :] += slow_trim_offset_even
        slow_disc_thr[1::2, :] += slow_trim_offset_odd
        #print(slow_disc_thr)
        # time.sleep(3)
        fast_disc_thr = data[:, ][:, 33:34]
        slow_disc_thr[slow_disc_thr < slow_trim_ok_min] = default_slow_trim
        slow_disc_thr[slow_disc_thr > slow_trim_ok_max] = default_slow_trim
        fast_disc_thr[fast_disc_thr < fast_trim_ok_min] = default_fast_trim
        fast_disc_thr[fast_disc_thr > fast_trim_ok_max] = default_fast_trim
        disc_thr = np.column_stack((slow_disc_thr, fast_disc_thr))
        
        #  convert to 2D list
        trim = [list(map(int, i)) for i in disc_thr.tolist()]

        # Write trim values to ASIC
        # print(" -- Write trim values --")
        for ch in range(128):
            for d in range(31):
                self.write(ch, 61 - 2*d, trim[ch][d])

            self.ch_disc_offset_dac = trim[ch][31]
            self.set_regFunc(smc.R_ACT, ch, 67, 0, 0x3f, trim[ch][31])
            self.write(ch, 67, self.get_reg(smc.R_ACT, ch, 67))

            log_line = "ch: " + \
                '{:3d} '.format(ch) + ''.join('\t {:3d}'.format(u)
                                              for u in trim[ch])
            # print(log_line)
            log.debug("%s", log_line)
        '''

    def set_trim_default(self, trim_slow: int = 128, trim_fast: int = 36):
        """ Set all ADC trims to a fixed  value
        args: trim_slow: global slow trim value
              trim_fast: global fast trim value
        returns: na
        """
        assert 0 < trim_slow < 256
        assert 0 < trim_fast < 256
        for ch in range(128):
            for d in range(31):
                self.write_u(ch, 61 - 2*d, trim_slow)

            self.ch_disc_offset_dac = trim_fast
            self.write_u(ch, 67, trim_fast)

            # log_line = "ch: " + \
            #    '{:3d} '.format(ch) + ''.join('\t {:3d}'.format(u)
            #                                  for u in trim[ch])
            # log.debug("%s", log_line)

    def read_trim(self) -> list:
        trim_l = [[disc for disc in range(31)] for ch in range(128)]
        trim_strs = []
        header_str = str(self.a_id) + " " + str(self.mseq) + " " + str(self.chrg) + " " + str(self.aseq)
        trim_strs.append(header_str)
        for ch in range(128):
            trim_str = str(ch).rjust(3) + ":\t"
            for disc in range(31):
                trim_l[ch][disc] = self.read(ch, 2*disc+1) & 0xff
                trim_str = trim_str + str(trim_l[ch][disc]).rjust(3) + " "
                trim_strs.append(trim_str)
        return trim_strs
 
    def read_dummy(self):
        """ Dummy method
           create just a log message
        args: na
        returns: na
        """
        log.info("\n\n DUMMY METHOD  \n\n " )

    # ------------------------------------------------------------------------
    # ------------------------------------------------------------------------
    # ------------------------------------------------------------------------
    # ------------------------------------------------------------------------
    # ------------------------------------------------------------------------
    # ------------------------------------------------------------------------


    def get_config(self, conf = {}, store = 0 ):
        if not conf:
            conf = {
                (127,63): -1,
                (127,65): -1,
                (127,67): -1,

                (130,0): -1,
                (130,1): -1,
                (130,2): -1,
                (130,3): -1,
                (130,5): -1,
                (130,6): -1,
                (130,7): -1,
                (130,8): -1,
                (130,9): -1,
                (130,10): -1,
                (130,11): -1,
                (130,12): -1,
                (130,13): -1,
                (130,14): -1,
                (130,15): -1,
                (130,16): -1,
                (130,17): -1,
                (130,18): -1,
                (130,20): -1,
                (130,21): -1,

                (192,3): -1,
                (192,18): -1,
                (192,19): -1,
                (192,20): -1,
                (192,21): -1,
                (192,23): -1,
                (192,27): -1,
                (192,28): -1,
                (192,29): -1,
                (192,36): -1                
            }       
        for reg, val in conf.items():
            log.debug(f"{reg} {type(reg)}    {reg[0]} {reg[1]}")
            rb_val = self.read(reg[0], reg[1])
            conf[reg] = rb_val
            
        if store & 1:
            # now = datetime.now()
            #     date =  hex(self.a_id)+now.strftime("-%y%m%d_%H%M%S")
            filename_conf= "asic_conf_" + hex(self.read_efuse()).rjust(18) + datetime.now().strftime("_%y%m%d_%H%M%S") + ".txt"
            myfile = open(filename_conf,"w")
            for reg, val in conf.items():
                myfile.write(str(reg)+"\t"+ hex(val).rjust(8) +"\n")    
            myfile.close()
        return conf
			
    def write_config(self, conf ):
        for reg, val in conf.items():
            self.write(reg[0], reg[1], val)
        return	
			
			
