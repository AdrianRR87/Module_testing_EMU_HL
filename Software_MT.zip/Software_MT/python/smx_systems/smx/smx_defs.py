R_INI  = 0
R_ACT  = 1
R_RBK  = 2
NR_SET = 3

SMX_CONF = 0
SMX_PICK = 1













