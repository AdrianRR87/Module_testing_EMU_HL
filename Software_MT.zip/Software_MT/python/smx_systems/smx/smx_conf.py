class SmxFunc:
    def __init__(self, dictionary: dict):
        for k, v in dictionary.items():
            setattr(self, k, v)


class SmxConf():
    def __init__(self, par_dict: dict):
        for f, d in par_dict.items():
            func = SmxFunc(d)
            fa = f[2:]                  # remove f_ from "par" key for attribute name
            setattr(self, fa, func )
            # print(fa, d, func)
