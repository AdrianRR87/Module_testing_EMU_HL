import logging as log
import glob

import msts_defs as smc

 
class smxTrim(object):

    def __init__(self, asic, trimfile_src):
        self.asic = asic
        self.vref_n = 0 
        self.vref_p = 0
        self.vref_t = 0
        self.disc_th2_glob = 0 
        self.p = -1
        self.trim = None
        self.trimfile_tag = ""
        
        if type(trimfile_src == dict):
            self.get_trim_from_date(trimfile_src)
        else:
            self.trimfile_tag = trimfile_src
            self.get_trim_from_tag(self.trimfile_tag, asic)
     
    def get_trim_from_date(self, calib_dict):    
        
        asic = self.asic 
        #cal = get_trim_from_id(a_id, calib)
        cal = self.get_trim_date_from_module(asic.mseq, 1-smc.cno[asic.chrg], asic.aseq, calib_dict)
        if len(cal) < 1:
            log.warning("No Trim File")
            return
        elif len(cal) > 1:
            log.warning("More than one Trim File for ASIC %d in config: %d", a_id, len(cal))
            return
        trim_file_datetime = cal[0]
        files = []
        # print(a_id, trim_file_datetime, "*"+trim_file_datetime+"*.txt", glob.glob("trim/"+"*"+trim_file_datetime+"*.txt"))
        for tfile in glob.glob("trim/"+"*"+trim_file_datetime+"*.txt"):
            # print("file", tfile)
            files.append(tfile)
        #print( files )    
        if len(files) > 1:
            log.warning("More than one trim  File with same datetime!!  %d", len(files))
            #print(files, trim_file_datetime)
            return
        if len(files) < 1:
            log.warning("No trim  File with proper datetime!! %d", len(files))
            #print(files, trim_file_datetime)
            return
        trim_file_name = files[0]
        parts = trim_file_name.split("_")
        log.debug(f"trim file name split: {trim_file_name}  into th2_glob {parts[9]}   vref_n {parts[10]}  vref_p {parts[11]}")
        self.disc_th2_glob = int(parts[8])
        self.vref_n         = int(parts[9])
        self.vref_p        = int(parts[10])        
        self.vref_t        = int(parts[11]) & 0x3ff
        pol_str            = parts[16].split(".")[0]
        if pol_str == "elect":
            self.p = smc.cno['n']
        elif pol_str == "holes":
            self.p = smc.cno['p']
        else:
            log.warning("unknown polarity string in trimfile name: %s", pol_str)
        self.trimfile_tag = trim_file_name    
        
    def get_trim_date_from_module(self, mseq, feb, aseq, f_trim_list):
        res = []
        ftrim = f_trim_list[mseq]       # get trim datetime for module no "seq"
        try:
            res.append(ftrim[feb][aseq])
        except Exception as e:
            log.error("exception in trim file selection %d %d %d", mseq, feb, aseq)
        return res

    def get_trim_from_tag(self, asic, tag):
        log.warning("Get trim file using tag (e.g. from DB) - not yet implemented!!")
        self.disc_th2_glob = 0
        self.ref_n         = 0
        self.vref_p        = 0        
        self.vref_t        = 0
        self.p             = 0        
        
        


# ToDo: check proper functionality
#   will be obsolete beyond mSTS modules 
def adjust_icsa_for_vddm_ldo(self, vddm_target: int = 1250, set_flag: bool = False):
	"""  automatic procedure for asics on FEB8
		 where vdm is supplied by 1.8V LDO
	Note: TODO: UNDER DEVELOPMENT, NOT YET WORKING!
	i_csa current settings are used to control diode voltage drop and thus vddm

	args: vddm_target: target value for the internally measure vddm
		  set_flag   : flag to control if asic is directly configured with final i_csa value
	returns: na
	"""
	log.warning("\n-----------\nMethod under developemnt! Does not provide reasonable outcome yet! \
				 Changes I_CSA settings!\n-----------\n")

	i_csa_tst_high = 48
	i_csa_tst_low = 7

	self.write(130, 0, i_csa_tst_high)
	self.write(130, 13, i_csa_tst_high)
	vddm_tst_high = self.read_vddm()
	self.write(130, 0, i_csa_tst_low)
	self.write(130, 13, i_csa_tst_low)
	vddm_tst_low = self.read_vddm()

	if ( vddm_tst_low - vddm_tst_high ) < 40:
		log.info(f" vddm's {vddm_tst_low} and {vddm_tst_high} too close. FEB with 1.2V LDO? Exiting  ")
		return
	else:
		log.info(f" vddm's {vddm_tst_low} and {vddm_tst_high} significantly different. Continue..")

	self.write(130, 20, 7)        # diag circuit sorce mux set to vddm
	# v_thr = (dac_thr**2)*(-0.0026)+6.8971*dac_thr+3.2474
	thr_target = 175  # ToTO vddm_target
	self.write(130, 22, thr_target)

	i_csa_temp = 0b100000
	for i in range(0, 6):
		self.write(130, 0, i_csa_temp)
		self.write(130, 13, i_csa_temp)
		time.sleep(0.01)
		result = self.read(192, 34)

		if result > 0:
			if i == 5:
				pass
			else:
				i_csa_temp = i_csa_temp | (2**(4-i))  # set next bit
		else:
			i_csa_temp = i_csa_temp & ~(2**(5-i))  # clear current
			if i == 5:
				pass
			else:
				i_csa_temp = i_csa_temp | (2**(4-i))  # set next bit

	vddm_final = self.read_vddm()
	log.info(f"Auto adjust of i_csa for asic {self.a_id}:  i_csa {i_csa_temp}\
			   gives vddm {vddm_final}  ( target {vddm_target}) ")
	self.write(130, 0, 7)    # TODO: set proper value
	self.write(130, 13, 7)
